﻿var SetFocusCommand = (function (_super) {
    __extends(SetFocusCommand, _super);
    function SetFocusCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    SetFocusCommand.prototype.execute = function () {
        var param = this.CommandParam;
        var targetCellFormula = param.TargetCell;

        var cellLocation = this.getCellLocation(targetCellFormula);
        this.SetFocusToDom(this, cellLocation, 0);
    };

    SetFocusCommand.prototype.SetFocusToDom = function (self, cellLocation, retryTime) {
        //PageloadedCommand set focus does not work, so try 10 times.
        if (retryTime > 10) {
            return;
        }

        var cell = Forguncy.Page.getCellByLocation(cellLocation);
        if (!cell) {
            return;
        }

        //Fix jira bug FORGUNCY-8299: [FromCN]Backspace can't delete char in textbox if listview check DisableAutoSelectRow
        //When listview enable DisableAutoSelectRow, it seems the sheet.clearSelection will get focus.
        //After user input char, spreadjs don't handle, textbox get the char, and after user input enter or direction key, spreadjs handle.
        Forguncy.Page.getListViews().forEach(list => list._grid.focus(false));

        cell.setFocus();
        if (!cell.hasFocus()) {
            retryTime++;
            Forguncy.DelayRefresh.setTimeout(function () {
                self.SetFocusToDom(self, cellLocation, retryTime);
            }, 100);
        }
    };
    return SetFocusCommand;
}(Forguncy.CommandBase));

Forguncy.CommandFactory.registerCommand("SetFocusCommand.SetFocusCommand, SetFocusCommand", SetFocusCommand);