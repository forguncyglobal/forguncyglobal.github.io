var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var ElementTheme;
(function (ElementTheme) {
    var colorDictionary = {
        "--el-color-primary": "Accent 1",
        "--el-color-primary-light-1": "Accent 1 10",
        "--el-color-primary-light-2": "Accent 1 20",
        "--el-color-primary-light-3": "Accent 1 30",
        "--el-color-primary-light-4": "Accent 1 40",
        "--el-color-primary-light-5": "Accent 1 50",
        "--el-color-primary-light-6": "Accent 1 60",
        "--el-color-primary-light-7": "Accent 1 70",
        "--el-color-primary-light-8": "Accent 1 80",
        "--el-color-primary-light-9": "Accent 1 90",
        "--el-color-primary-dark-2": "Accent 1 -20",
    };
    var updated = false;
    function updateCssAndAppend() {
        if (updated) {
            return;
        }
        var cssStr = "";
        for (var key in colorDictionary) {
            cssStr += "".concat(key, ":").concat(Forguncy.ConvertToCssColor(colorDictionary[key]), ";");
        }
        cssStr = ":root{ ".concat(cssStr, " }");
        var style = document.createElement("style");
        style.type = "text/css";
        style.id = "FGC_Element_Plus_Variables";
        style.innerHTML = cssStr;
        document.getElementsByTagName("head")[0].appendChild(style);
        updated = true;
    }
    ElementTheme.updateCssAndAppend = updateCssAndAppend;
})(ElementTheme || (ElementTheme = {}));
var ElementCellTypes;
(function (ElementCellTypes) {
    var CultureEnum;
    (function (CultureEnum) {
        CultureEnum["CN"] = "ElementPlusLocaleZhCn";
        CultureEnum["EN"] = "ElementPlusLocaleEn";
        CultureEnum["KR"] = "ElementPlusLocaleKo";
        CultureEnum["JA"] = "ElementPlusLocaleJa";
    })(CultureEnum || (CultureEnum = {}));
    ElementCellTypes.iconComponent = Vue.defineComponent({
        template: "<el-icon v-html=\"icon\" />",
        props: {
            icon: String
        }
    });
    ElementCellTypes.imageComponent = Vue.defineComponent({
        template: "<el-image class=\"el-icon\" fit=\"contain\" :src=\"src\" />",
        props: {
            src: String
        }
    });
    ElementCellTypes.getBase64FromSvgElement = function (svgStr) {
        return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgStr)));
    };
    var ElementCellTypeBase = /** @class */ (function (_super) {
        __extends(ElementCellTypeBase, _super);
        function ElementCellTypeBase() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._styleContainerIdSet = new Set();
            _this.cellType = _this.CellElement.CellType;
            _this._cellStyle = {};
            return _this;
        }
        Object.defineProperty(ElementCellTypeBase.prototype, "fontDom", {
            get: function () {
                return this._fontDom;
            },
            set: function (value) {
                this._fontDom = value;
                this.setFontToDom();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ElementCellTypeBase.prototype, "fontSelector", {
            get: function () {
                return this._fontSelector;
            },
            set: function (value) {
                this._fontSelector = value;
                this.setFontStyleElement();
            },
            enumerable: false,
            configurable: true
        });
        ElementCellTypeBase.prototype.createVueApp = function (option) {
            var self = this;
            if (option.beforeCreate) {
                var beforeCreate_1 = option.beforeCreate;
                option.beforeCreate = function () {
                    self.vue = this;
                    beforeCreate_1();
                };
            }
            else {
                option.beforeCreate = function () {
                    self.vue = this;
                };
            }
            var vueApp = Vue.createApp(option);
            vueApp.use(window.ElementPlus, {
                locale: window[CultureEnum[Forguncy.RS.Culture]],
            });
            vueApp.mount("#".concat(this.uId));
            this._vueApp = vueApp;
        };
        ElementCellTypeBase.prototype.setFontStyle = function (styleInfo) {
            var currentStyleInfo = this._cellStyle;
            currentStyleInfo.FontFamily = styleInfo.FontFamily;
            currentStyleInfo.FontStyle = styleInfo.FontStyle;
            currentStyleInfo.FontSize = styleInfo.FontSize;
            currentStyleInfo.FontWeight = styleInfo.FontWeight;
            currentStyleInfo.Foreground = styleInfo.Foreground;
            currentStyleInfo.Strikethrough = styleInfo.Strikethrough;
            currentStyleInfo.Underline = styleInfo.Underline;
            this.setFontToDom();
            this.setFontStyleElement();
        };
        ElementCellTypeBase.prototype.getStyles = function () {
            var _a, _b;
            var styleInfo = (_a = this._cellStyle) !== null && _a !== void 0 ? _a : {};
            var styles = {
                "font-family": (_b = styleInfo.FontFamily) !== null && _b !== void 0 ? _b : "",
                "font-size": styleInfo.FontSize && styleInfo.FontSize > 0 ? styleInfo.FontSize : "",
                "font-style": styleInfo.FontStyle ? styleInfo.FontStyle.toLowerCase() : "",
                "font-weight": styleInfo.FontWeight ? styleInfo.FontWeight.toLowerCase() : "",
            };
            var textDecoration = [];
            if (styleInfo.Underline) {
                textDecoration.push("underline");
            }
            if (styleInfo.Strikethrough) {
                textDecoration.push("line-through");
            }
            styles["text-decoration"] = textDecoration.join(" ");
            styles["color"] = styleInfo.Foreground ? Forguncy.ConvertToCssColor(styleInfo.Foreground) : "";
            return styles;
        };
        ElementCellTypeBase.prototype.getStyleContainerElement = function (prefix) {
            var id = "".concat(this.uId, "-style-").concat(prefix);
            this._styleContainerIdSet.add(id);
            var el = document.getElementById(id);
            if (el) {
                return el;
            }
            var style = document.createElement("style");
            style.type = "text/css";
            style.id = id;
            document.getElementsByTagName("head")[0].appendChild(style);
            return style;
        };
        ElementCellTypeBase.prototype.setFontStyleElement = function () {
            var _this = this;
            if (!this._fontSelector) {
                return;
            }
            var styles = this.getStyles();
            var str = "";
            Object.keys(styles).forEach(function (key) {
                var value = styles[key];
                if (!value) {
                    return;
                }
                if (key === "font-size") {
                    value += "px";
                }
                str += "".concat(key, ":").concat(value, " !important;");
            });
            var selectorArray = typeof this._fontSelector === 'string' ? [this.fontSelector] : this.fontSelector;
            var selector = selectorArray.map(function (item) { return ".".concat(_this.uId, " ").concat(item); }).join(",");
            this.getStyleContainerElement("font").innerHTML = "".concat(selector, "{").concat(str, "}");
        };
        ElementCellTypeBase.prototype.setFontToDom = function () {
            var _a;
            (_a = this.fontDom) === null || _a === void 0 ? void 0 : _a.css(this.getStyles());
        };
        ElementCellTypeBase.generateID = function (prefix) {
            if (prefix === void 0) { prefix = "fgc-el"; }
            return "".concat(prefix, "-").concat(new Date().getTime().toString(36), "-").concat(Math.random().toString(36).slice(2));
        };
        ElementCellTypeBase.prototype.createContent = function () {
            ElementTheme.updateCssAndAppend();
            this.uId = ElementCellTypeBase.generateID();
            // 外边加一层Div，设置ID，否则在输入值是ValidateTooltip不消失
            var container = $("<div id=".concat(this.ID, "><div id =\"").concat(this.uId, "\" class=\"").concat(this.uId, "\" style='width:100%;height:100%'></div></div>"))
                .css("width", "100%")
                .css("height", "100%");
            this._cellStyle = this.CellElement.StyleInfo;
            this.vueContainer = container;
            return container;
        };
        ElementCellTypeBase.prototype.addCustomClass = function (className) {
            this.getContainer().addClass(className);
        };
        ElementCellTypeBase.prototype.loop = function () {
            return undefined;
        };
        ElementCellTypeBase.prototype.setValueToElement = function (jelement, value) {
            var _a;
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue) || this.loop)(value);
        };
        ElementCellTypeBase.prototype.getValueFromElement = function () {
            var _a;
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.getValue) || this.loop)();
        };
        ElementCellTypeBase.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.onIsDisabledChanged();
        };
        ElementCellTypeBase.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.onIsDisabledChanged();
        };
        ElementCellTypeBase.prototype.onIsDisabledChanged = function () {
            var _a, _b, _c, _d;
            if (!this.vue) {
                return;
            }
            if (this.isDisabled()) {
                (_b = (_a = this.vue).disable) === null || _b === void 0 ? void 0 : _b.call(_a);
            }
            else {
                (_d = (_c = this.vue).enable) === null || _d === void 0 ? void 0 : _d.call(_c);
            }
        };
        ElementCellTypeBase.prototype.setReadOnly = function (value) {
            var _a;
            _super.prototype.setReadOnly.call(this, value);
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setReadOnly) || this.loop)(this.isReadOnly());
        };
        ElementCellTypeBase.prototype.onPageLoaded = function (info) {
            var _a;
            this.setFontToDom();
            this.setReadOnly(info.isReadOnly);
            if (info.isDisabled) {
                this.disable();
            }
            else {
                this.enable();
            }
            if ((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue) {
                this.vue.setValue(info.value);
            }
        };
        ElementCellTypeBase.prototype.calcNumber = function (value) {
            if (value === 0) {
                return value;
            }
            if (value) {
                if (typeof (value) === "string") {
                    value = this.evaluateFormula(value);
                }
                return Number(value);
            }
        };
        ElementCellTypeBase.prototype.isFormula = function (value) {
            return !this.isEmpty(value) && value.toString()[0] === "=";
        };
        ElementCellTypeBase.prototype.destroy = function () {
            var _a;
            (_a = this._vueApp) === null || _a === void 0 ? void 0 : _a.unmount();
            this._fontDom = null;
            this.fontSelector = null;
            this._styleContainerIdSet.forEach(function (eid) { var _a; return (_a = document.getElementById(eid)) === null || _a === void 0 ? void 0 : _a.remove(); });
            _super.prototype.destroy.call(this);
        };
        ElementCellTypeBase.prototype.getIconComponent = function (icon, callback) {
            this.getIcon(icon, function (result) {
                if (result.isSvg) {
                    callback(Vue.h(ElementCellTypes.iconComponent, { icon: result.icon }), result);
                }
                else {
                    callback(Vue.h(ElementCellTypes.imageComponent, { src: result.icon }), result);
                }
            });
        };
        ElementCellTypeBase.prototype.getIcon = function (icon, callback) {
            if (icon) {
                if (typeof (icon) === "string") {
                    var src_1 = icon;
                    if (ElementCellTypeBase.isAttachment(src_1)) {
                        src_1 = Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer() + encodeURIComponent(src_1);
                    }
                    callback({
                        icon: src_1,
                        isSvg: false
                    });
                }
            }
            if (!(icon === null || icon === void 0 ? void 0 : icon.Name)) {
                return;
            }
            var src;
            if (icon.BuiltIn) {
                src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + icon.Name;
            }
            else {
                src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(icon.Name);
            }
            if (Forguncy.ImageDataHelper.IsSvg(src)) {
                $.get(src, function (data) {
                    var svg = $(data.documentElement);
                    Forguncy.ImageHelper.preHandleSvg(svg, icon.UseCellTypeForeColor ? "currentColor" : icon.Color);
                    callback({
                        "icon": svg[0].outerHTML,
                        isSvg: true
                    });
                });
            }
            else {
                callback({
                    icon: src,
                    isSvg: false
                });
            }
        };
        ElementCellTypeBase.isAttachment = function (src) {
            if (typeof src !== "string") {
                return false;
            }
            src = src.toLowerCase();
            if (src.indexOf("http") === 0) {
                return false;
            }
            if (src.length < 37 || src[36] !== "_") {
                return false;
            }
            // FORGUNCY-5372 [VideoPlayer]External video set as the FilePreviewer cell, the video cannot play in runtime
            //if (src[src.length - 1] !== "|") {
            //    return false;
            //}
            // ---------------------
            return true;
        };
        ElementCellTypeBase.prototype.isEmpty = function (v) {
            return v === null || v === undefined || v === "";
        };
        ElementCellTypeBase.prototype.refreshUI = function () {
            var _a;
            (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.$forceUpdate) || this.loop)();
        };
        ElementCellTypeBase.prototype.isValidDate = function (date) {
            return date instanceof Date && !isNaN(date.getTime());
        };
        ElementCellTypeBase.prototype.getCustomSlotByPath = function (slotPath) {
            var _a, _b;
            var slot = this.getPropertyByPath(window.FgcElement, slotPath.split("."));
            var slotStr = "";
            if (slot) {
                var classNames = (_b = (_a = this.CellElement.CssClassName) === null || _a === void 0 ? void 0 : _a.split(" ")) !== null && _b !== void 0 ? _b : [];
                for (var _i = 0, classNames_1 = classNames; _i < classNames_1.length; _i++) {
                    var name_1 = classNames_1[_i];
                    var selectSlotFunc = slot[name_1];
                    slotStr = selectSlotFunc ? selectSlotFunc() : "";
                    slotStr = typeof slotStr === "string" ? slotStr : "";
                    break;
                }
            }
            return slotStr;
        };
        ElementCellTypeBase.prototype.getPropertyByPath = function (target, pathes) {
            var result = target !== null && target !== void 0 ? target : {};
            for (var _i = 0, pathes_1 = pathes; _i < pathes_1.length; _i++) {
                var item = pathes_1[_i];
                var property = result[item];
                if (property !== undefined) {
                    result = property;
                }
                else {
                    return null;
                }
            }
            return result;
        };
        return ElementCellTypeBase;
    }(Forguncy.Plugin.CellTypeBase));
    ElementCellTypes.ElementCellTypeBase = ElementCellTypeBase;
    var SlotPath;
    (function (SlotPath) {
        SlotPath["selectPrefix"] = "SelectSlots.Prefix";
        SlotPath["selectOption"] = "SelectSlots.Option";
        SlotPath["datePickerRangeSeparater"] = "DatePickerSlots.RangeSeparater";
        SlotPath["datePickerCell"] = "DatePickerSlots.Cell";
        SlotPath["cascaderNode"] = "CascaderSlots.Node";
        SlotPath["calendarCell"] = "CalendarSlots.Cell";
        SlotPath["calendarHeader"] = "CalendarSlots.Header";
        SlotPath["menuItemContent"] = "MenuItemSlots.Content";
        SlotPath["backTopContent"] = "BackTopSlots.Content";
    })(SlotPath = ElementCellTypes.SlotPath || (ElementCellTypes.SlotPath = {}));
    var InputCellTypeBaseParam = /** @class */ (function () {
        function InputCellTypeBaseParam() {
        }
        return InputCellTypeBaseParam;
    }());
    ElementCellTypes.InputCellTypeBaseParam = InputCellTypeBaseParam;
    var InputCellTypeBase = /** @class */ (function (_super) {
        __extends(InputCellTypeBase, _super);
        function InputCellTypeBase() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputCellTypeBase.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
            this.getContainer().keyup(function () {
                var _a, _b;
                if (_this._inputTextCache !== ((_a = _this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString())) {
                    _this.hideValidateTooltip();
                }
                _this._inputTextCache = (_b = _this.getValueFromElement()) === null || _b === void 0 ? void 0 : _b.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        InputCellTypeBase.prototype.setValueToElement = function (jElement, value) {
            var _a;
            _super.prototype.setValueToElement.call(this, jElement, value);
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
        };
        return InputCellTypeBase;
    }(ElementCellTypeBase));
    ElementCellTypes.InputCellTypeBase = InputCellTypeBase;
    var SupportDataSourceCellType = /** @class */ (function () {
        function SupportDataSourceCellType() {
        }
        SupportDataSourceCellType.refreshData = function (cellType, bindingDataSourceModel, callBack, options) {
            if (options === void 0) { options = null; }
            this.refreshDataWithOption(cellType, bindingDataSourceModel, callBack, options);
        };
        SupportDataSourceCellType.refreshDataWithOption = function (cellType, bindingDataSourceModel, callBack, options, watchOnDependenceChange) {
            var _this = this;
            if (watchOnDependenceChange === void 0) { watchOnDependenceChange = true; }
            cellType.getBindingDataSourceValue(bindingDataSourceModel, options, function (dataSource) {
                callBack(dataSource);
            });
            if (watchOnDependenceChange) {
                cellType.onDependenceCellValueChanged(function () {
                    _this.refreshDataWithOption(cellType, bindingDataSourceModel, callBack, options, false);
                });
            }
        };
        return SupportDataSourceCellType;
    }());
    ElementCellTypes.SupportDataSourceCellType = SupportDataSourceCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var AvatarShape;
    (function (AvatarShape) {
        AvatarShape[AvatarShape["circle"] = 0] = "circle";
        AvatarShape[AvatarShape["square"] = 1] = "square";
    })(AvatarShape || (AvatarShape = {}));
    // test webhook
    var AvatarFit;
    (function (AvatarFit) {
        AvatarFit[AvatarFit["fill"] = 0] = "fill";
        AvatarFit[AvatarFit["contain"] = 1] = "contain";
        AvatarFit[AvatarFit["cover"] = 2] = "cover";
        AvatarFit[AvatarFit["none"] = 3] = "none";
        AvatarFit[AvatarFit["scale-down"] = 4] = "scale-down";
    })(AvatarFit || (AvatarFit = {}));
    var AvatarCellType = /** @class */ (function (_super) {
        __extends(AvatarCellType, _super);
        function AvatarCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        AvatarCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var badge = this.evaluateFormula(cellType.badge);
            this.addCustomClass("el-avatar-custom");
            if (cellType.shape === AvatarShape.circle) {
                this.addCustomClass("el-avatar-circle-custom");
            }
            var option = {
                template: "\n<el-badge :value=\"badge\" :hidden=\"!badge\">\n        <el-avatar\n            :src=\"src\"\n            :icon=\"icon\"            \n            :fit=\"fit\"\n            :text=\"text\"\n            :shape=\"shape\"\n            :size=\"size\">{{text}}\n        </el-avatar>\n    </el-badge>",
                data: function () {
                    return {
                        icon: "",
                        src: cellType.src,
                        fit: AvatarFit[cellType.fit],
                        shape: AvatarShape[cellType.shape],
                        size: null,
                        badge: badge,
                        text: undefined,
                    };
                },
                mounted: function () {
                    this.size = Math.min(self.vueContainer.width(), self.vueContainer.height());
                    var hasCommandList = cellType.CommandList && cellType.CommandList.length;
                    var avatarElement = $(".el-avatar", self.vueContainer);
                    if (hasCommandList) {
                        avatarElement.css("cursor", "pointer");
                        avatarElement.click(function () { return (self.executeCommand(cellType.CommandList)); });
                    }
                    self.fontDom = $(".el-avatar", self.getContainer());
                },
                methods: {
                    getValue: function () {
                        return this.src;
                    },
                    setValue: function (value) {
                        if (!value) {
                            this.src = self._defaultSrc;
                            this.text = undefined;
                            return;
                        }
                        if (cellType.showSystemAvatar) {
                            this.src = Forguncy.Helper.SpecialPath.getBaseUrl() + "Account/UserImage?getDefault=false&userName=" + value;
                            this.text = value;
                            return;
                        }
                        if (value && ElementCellTypes.FileHelper.IsAttachment(value)) {
                            value = ElementCellTypes.FileHelper.GetUploadImageSrc(value);
                        }
                        else if (value) {
                            var lowCase = (value + "").toLowerCase();
                            if (lowCase.indexOf("http://") !== 0 && lowCase.indexOf("https://") !== 0) {
                                this.text = value;
                            }
                        }
                        this.src = value;
                    }
                }
            };
            this.createVueApp(option);
            this.onDependenceCellValueChanged(function () {
                if (_this.isFormula(cellType.badge)) {
                    _this.vue.badge = _this.evaluateFormula(cellType.badge);
                }
            });
            this.getContainer().css("overflow", "");
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.icon, function (icon, result) {
                if (result.isSvg) {
                    self._defaultSrc = ElementCellTypes.getBase64FromSvgElement(result.icon);
                }
                else {
                    self._defaultSrc = result.icon;
                }
                if (_this.isEmpty(_this.vue.src)) {
                    _this.vue.src = self._defaultSrc;
                }
            });
        };
        AvatarCellType.prototype.onWindowResized = function () {
            this.vue.size = Math.min(this.vueContainer.width(), this.vueContainer.height());
        };
        AvatarCellType.prototype.clickable = function () {
            var cellType = this.CellElement.CellType;
            return cellType.CommandList && cellType.CommandList.length > 0;
        };
        return AvatarCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.AvatarCellType = AvatarCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.AvatarCellType, ElementUI", ElementCellTypes.AvatarCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var BackupTopCellType = /** @class */ (function (_super) {
        __extends(BackupTopCellType, _super);
        function BackupTopCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BackupTopCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            this.containerId = "".concat(this.uId, "-el-backuptop");
            var initData = {};
            // do nothing
            Object.assign(initData, {
                style: '',
                right: cellType.Right,
                bottom: cellType.Bottom
            });
            var contentSlot = this.getCustomSlotByPath(ElementCellTypes.SlotPath.backTopContent);
            var findHasScrollBarDom = function (el) {
                if (!el) {
                    return null;
                }
                var overflowY = el.css("overflow-y");
                if (overflowY === "auto" || overflowY === "scroll") {
                    return el;
                }
                var parent = el === null || el === void 0 ? void 0 : el.parent();
                return parent ? findHasScrollBarDom(parent) : null;
            };
            var targetTemplate;
            var el = findHasScrollBarDom(this.vueContainer);
            if (el === null || el === void 0 ? void 0 : el.length) {
                if (!el.attr("id")) {
                    el.attr("id", ElementCellTypes.ElementCellTypeBase.generateID("fgc-el-backupTop-random-id"));
                }
                targetTemplate = "target=\"#".concat(el.attr("id"), "\"");
            }
            var option = {
                el: "#".concat(this.uId),
                template: "\n<el-backtop id=\"".concat(this.containerId, "\" :style=\"style\" :visibilityHeight=\"visibilityHeight\" :right=\"right\" :bottom=\"bottom\" ").concat(targetTemplate, " >\n    ").concat(contentSlot || (info === null || info === void 0 ? void 0 : info.value) || "", "\n</el-backtop>"),
                data: function () {
                    return Object.assign({
                        visibilityHeight: cellType.VisibilityHeight,
                    }, initData);
                },
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        return BackupTopCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.BackupTopCellType = BackupTopCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.BackupTopCellType, ElementUI", ElementCellTypes.BackupTopCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var BreadcrumbCellType = /** @class */ (function (_super) {
        __extends(BreadcrumbCellType, _super);
        function BreadcrumbCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        BreadcrumbCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            var self = this;
            var option = {
                el: "#" + this.uId,
                template: "<el-breadcrumb :separator=\"separator\">\n<template v-for=\"(path,index) in paths\">\n  <el-breadcrumb-item><a :href=\"path.href\" @click=\"ItemClick(path,index)\">{{path.pageName}}</a></el-breadcrumb-item>\n</template>\n</el-breadcrumb>",
                data: function () {
                    return {
                        paths: [],
                        pageName: undefined,
                        separator: cellType.separator
                    };
                },
                methods: {
                    ItemClick: function (node, index) {
                        var _a, _b;
                        if (index !== this.paths.length - 1 && ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length)) {
                            var initValue = {};
                            initValue[cellType.ClickCommand.ParamProperties["pageName"]] = node.pageName;
                            self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                        }
                        event.preventDefault();
                    },
                    getValue: function () {
                        return this.pageName;
                    },
                    setValue: function (value) {
                        if (value instanceof Array) {
                            value = value.join(cellType.separator);
                        }
                        this.pageName = value === null || value === void 0 ? void 0 : value.toString();
                        this.initPath();
                    },
                    initPath: function () {
                        var _this = this;
                        if (this.pageName) {
                            var pathStrs = this.pageName.split(cellType.separator).filter(function (i) { return i; });
                            var baseUrl_1 = Forguncy.Helper.SpecialPath.getBaseUrl();
                            this.paths = pathStrs.map(function (i) { return ({
                                pageName: i,
                                href: baseUrl_1 + i
                            }); });
                            this.$nextTick(function (_) {
                                var container = $(_this.$el);
                                self.fontDom = $("a,span", container);
                                self.setFontToDom();
                            });
                        }
                        else {
                            this.paths = [];
                        }
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        return BreadcrumbCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.BreadcrumbCellType = BreadcrumbCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.BreadcrumbCellType, ElementUI", ElementCellTypes.BreadcrumbCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var CalendarCellType = /** @class */ (function (_super) {
        __extends(CalendarCellType, _super);
        function CalendarCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CalendarCellType.prototype.clearTimer = function () {
            clearTimeout(this._timer);
        };
        CalendarCellType.prototype.resetTimer = function (fn) {
            clearTimeout(this._timer);
            this._timer = setTimeout(fn, 300);
        };
        CalendarCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var dateCellStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.calendarCell);
            var calendarHeaderStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.calendarHeader);
            var self = this;
            var cellType = this.cellType;
            this.addCustomClass("el-calendar-custom");
            var template = "\n            <el-calendar v-model=\"value\">\n                <template #dateCell=\"{ data }\">\n                     ".concat(dateCellStr || self.getDefaultDateCellSlot(), "\n                </template>\n                ").concat(calendarHeaderStr ? "<template #header='data'>" + calendarHeaderStr + "</template>" : "", "\n            </el-calendar>\n");
            var option = {
                template: template,
                data: function () {
                    return {
                        value: null,
                        options: [],
                        scheduleMap: {},
                        insufficientHeight: false,
                        firstDayOfWeek: cellType.firstDayOfWeek,
                        calendarContainerStyle: null,
                    };
                },
                mounted: function () {
                    var height = Math.floor($(".el-calendar-day", this.$el).height());
                    if (height <= 30) {
                        this.insufficientHeight = true;
                    }
                    this.calendarContainerStyle = "height:".concat(height, "px;");
                },
                created: function () {
                    ElementUtils.Dayjs.toggleLocale({ weekStart: cellType.firstDayOfWeek });
                },
                methods: {
                    getValue: function () {
                        return Forguncy.ConvertDateToOADate(this.value);
                    },
                    setValue: function (value) {
                        self.cacheOldValue = value ? Forguncy.ConvertOADateToDate(value) : null;
                        this.value = self.cacheOldValue;
                    },
                    formatDay: function (value) {
                        return value.split('-')[2];
                    },
                    getScheduleMapKeyByDate: function (date) {
                        return date === null || date === void 0 ? void 0 : date.toLocaleDateString();
                    },
                    clearScheduleMap: function () {
                        this.scheduleMap = {};
                    },
                    fillScheduleMap: function () {
                        var _this = this;
                        this.options.forEach(function (option) {
                            var isOADate = !isNaN(Number(option.date));
                            var date = isOADate ?
                                Forguncy.ConvertOADateToDate(option.date) :
                                new Date(option.date);
                            var key = _this.getScheduleMapKeyByDate(date);
                            if (_this.scheduleMap[key]) {
                                _this.scheduleMap[key].push(option);
                            }
                            else {
                                _this.scheduleMap[key] = [option];
                            }
                        });
                    },
                    getOptionsByDay: function (dateCell) {
                        var key = this.getScheduleMapKeyByDate(dateCell.date);
                        return (this.scheduleMap[key] || []);
                    },
                    handleDoubleClick: function (data) {
                        var _a;
                        var command = cellType.DBClickCommand;
                        if (!command) {
                            return;
                        }
                        self.executeCustomCommandObject(command, (_a = {},
                            _a[command.ParamProperties["date"]] = data.date,
                            _a), "doubleClick");
                    },
                    scheduleOnClickOrDBClick: function (type, option) {
                        var _a;
                        var command = type === "click" ? cellType.ScheduleClickCommand : cellType.ScheduleDBClickCommand;
                        if (!command) {
                            return;
                        }
                        var ParamProperties = command.ParamProperties;
                        var initParam = (_a = {},
                            _a[ParamProperties["value"]] = option.value,
                            _a[ParamProperties["text"]] = option.text,
                            _a[ParamProperties["date"]] = option.date,
                            _a);
                        self.executeCustomCommandObject(command, initParam, "schedule" + type);
                    },
                    scheduleOnClick: function (option) {
                        var _this = this;
                        self.resetTimer(function () { return _this.scheduleOnClickOrDBClick("click", option); });
                    },
                    scheduleOnDoubleClick: function (event, option) {
                        self.clearTimer();
                        if (cellType.DBClickCommand) {
                            event.stopPropagation();
                        }
                        this.scheduleOnClickOrDBClick("dbclick", option);
                    }
                },
                watch: {
                    value: function (newValue, oldValue) {
                        var _a;
                        if (((_a = self.cacheOldValue) === null || _a === void 0 ? void 0 : _a.getTime()) !== (newValue === null || newValue === void 0 ? void 0 : newValue.getTime())) {
                            self.commitValue();
                        }
                    },
                    options: function (newValue, oldValue) {
                        this.clearScheduleMap();
                        this.fillScheduleMap();
                    }
                }
            };
            this.createVueApp(option);
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                _this.vue.options = dataSource;
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        CalendarCellType.prototype.reload = function () {
            var _this = this;
            var cellType = this.cellType;
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                _this.vue.options = dataSource;
            });
        };
        CalendarCellType.prototype.getDefaultDateCellSlot = function () {
            return "\n            <div class=\"calendar-container\" :style=\"calendarContainerStyle\" v-if=\"calendarContainerStyle\" @dblclick=\"handleDoubleClick(data)\">\n                <div class=\"calendar-date-container\">\n                    <div>{{ formatDay(data.day)}}</div>\n                    <div>\n                        <div class=\"fgc-calendar-ellipsis\" v-if=\"insufficientHeight && getOptionsByDay(data).length\"/>\n                    </div>\n                </div>\n                <div class=\"calendar-schedule-container\" v-if=\"!insufficientHeight\">\n                    <el-scrollbar>\n                        <div class=\"calendar-schedule-item\" v-for=\"option in getOptionsByDay(data)\" \n                            @click=\"scheduleOnClick(option)\" @dblclick=\"scheduleOnDoubleClick($event,option)\">\n                            <div :title=\"option.text\" class=\"calendar-schedule-item-text\">{{option.text}}</div>\n                        </div>\n                    </el-scrollbar>\n                </div>\n            </div>";
        };
        return CalendarCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.CalendarCellType = CalendarCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.CalendarCellType, ElementUI", ElementCellTypes.CalendarCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var ExpendTrigger;
    (function (ExpendTrigger) {
        ExpendTrigger[ExpendTrigger["Click"] = 0] = "Click";
        ExpendTrigger[ExpendTrigger["Hover"] = 1] = "Hover";
    })(ExpendTrigger || (ExpendTrigger = {}));
    var CascaderCellType = /** @class */ (function (_super) {
        __extends(CascaderCellType, _super);
        function CascaderCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CascaderCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        CascaderCellType.prototype.onPageLoaded = function (info) {
            var nodeStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.cascaderNode);
            var self = this;
            var cellType = this.cellType;
            var options = [];
            if (!cellType.useBinding && cellType.options) {
                options = cellType.options;
            }
            this.addCustomClass("el-cascader-custom");
            var emitPath = cellType.emitPath && !cellType.multiple;
            var valueIsArrayStructure = emitPath || cellType.multiple;
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var option = {
                template: "\n<el-cascader\nv-model=\"value\"\n:options=\"options\"\n:props=\"props\"\n:placeholder=\"placeholder\"\n:disabled = \"disabled\"\n:clearable= \"clearable\"\n:show-all-levels = \"showAllLevels\"\n:collapse-tags = \"collapseTags\"\n:separator = \"separator\"\n:filterable = \"filterable\"\n:tag-type=\"tagType\"\npopper-class=\"".concat(popperClass, "\"\nref=\"elInput\"\n@change=\"handleChange\"\nstyle=\"height:100%;width:100%\"\n>\n    ").concat(nodeStr ? "<template #default='{ node, data }'>" + nodeStr + "</template>" : "", "\n</el-cascader>\n"),
                data: function () {
                    return {
                        disabled: cellType.IsDisabled,
                        value: null,
                        props: {
                            expandTrigger: cellType.expandTrigger === ExpendTrigger.Click ? "click" : "hover",
                            multiple: cellType.multiple,
                            emitPath: !!emitPath,
                            checkStrictly: cellType.checkStrictly
                        },
                        options: options,
                        tagType: cellType.tagType,
                        placeholder: cellType.placeholder,
                        clearable: cellType.clearable,
                        showAllLevels: cellType.showAllLevels ? true : false,
                        collapseTags: cellType.collapseTags,
                        separator: cellType.separator,
                        filterable: cellType.filterable
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    getValue: function () {
                        var value = this.value;
                        if (value instanceof Array) {
                            return value.join(",");
                        }
                        return value;
                    },
                    setValue: function (value) {
                        var _a;
                        if (self.isEmpty(value)) {
                            this.value = null;
                            return;
                        }
                        if (valueIsArrayStructure) {
                            var values_1 = [];
                            var stringValues = value.toString().split(",");
                            stringValues.reduce(function (options, cur) {
                                if (!Array.isArray(options) || !options.length) {
                                    return [];
                                }
                                // 此处比较需要忽略类型，使用双等号
                                // eslint-disable-next-line
                                var item = options.find(function (item) { return item.value == cur; });
                                if (!item) {
                                    return [];
                                }
                                values_1.push(item.value);
                                return item.children;
                            }, this.options);
                            this.value = values_1;
                        }
                        else {
                            var flatOptions = ElementCellTypes.TreeHelper.flat(this.options);
                            // 这里认为字符串数字与数字等价，双等号不能去掉
                            // eslint-disable-next-line
                            var option_1 = flatOptions.find(function (o) { return o.value == value; });
                            this.value = (_a = option_1 === null || option_1 === void 0 ? void 0 : option_1.value) !== null && _a !== void 0 ? _a : null;
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setOptions: function (options) {
                        if (options) {
                            this.options = options;
                        }
                        else {
                            this.options = [];
                        }
                    }
                },
                mounted: function () {
                    self.fontDom = $("input", "#".concat(self.uId));
                    self.setFontToDom();
                }
            };
            this.createVueApp(option);
            self.ReloadBindingItems();
            _super.prototype.onPageLoaded.call(this, info);
        };
        CascaderCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (data) { return _this.setDataSource(ElementCellTypes.TreeHelper.build(data)); });
            }
        };
        CascaderCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        CascaderCellType.prototype.SetDataSourceByObjTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (childrenProperty) {
                childrenProperty = childrenProperty.split('|');
            }
            if (valueProperty) {
                valueProperty = valueProperty.split('|');
            }
            labelProperty = labelProperty ? labelProperty.split('|') : valueProperty;
            var source = this.buildTree(dataSource, valueProperty, labelProperty, childrenProperty);
            this.setDataSource(source);
        };
        CascaderCellType.prototype.buildTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            var _this = this;
            if (!dataSource) {
                return undefined;
            }
            return dataSource.map(function (i) { return ({
                value: _this.getSubPropertyValue(i, valueProperty),
                label: _this.getSubPropertyValue(i, labelProperty),
                children: _this.buildTree(_this.getSubPropertyValue(i, childrenProperty), valueProperty, labelProperty, childrenProperty),
            }); });
        };
        CascaderCellType.prototype.getSubPropertyValue = function (obj, subProperties) {
            for (var _i = 0, subProperties_1 = subProperties; _i < subProperties_1.length; _i++) {
                var prop = subProperties_1[_i];
                if (obj[prop] !== undefined) {
                    return obj[prop];
                }
            }
            return undefined;
        };
        CascaderCellType.prototype.SetDataSourceByIdPidTable = function (dataSource, valueProperty, labelProperty, parentValue) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var treeObj = ElementCellTypes.TreeHelper.build(dataSource.map(function (i) { return (__assign(__assign({}, i), { value: i[valueProperty], label: i[labelProperty], parentValue: i[parentValue] })); }));
            this.setDataSource(treeObj);
        };
        CascaderCellType.prototype.GetCheckedNodes = function (leafOnly) {
            if (typeof (leafOnly) === "string") {
                leafOnly = !(leafOnly.toLowerCase() === "false" || leafOnly.toLowerCase() === "0");
            }
            else {
                leafOnly = !!leafOnly;
            }
            return {
                CheckedItems: this.vue.$refs.elInput.getCheckedNodes(leafOnly).map(function (i) { return ({
                    "value": i.value,
                    "label": i.label,
                }); })
            };
        };
        return CascaderCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.CascaderCellType = CascaderCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.CascaderCellType, ElementUI", ElementCellTypes.CascaderCellType);
var ElementCellTypes;
(function (ElementCellTypes) {
    var FileHelper = /** @class */ (function () {
        function FileHelper() {
        }
        FileHelper.IsAttachment = function (str) {
            return /^[0-9a-f]{8}-?[0-9a-f]{4}-?[1-5][0-9a-f]{3}-?[89ab][0-9a-f]{3}-?[0-9a-f]{12}_.+$/i.test(str);
        };
        FileHelper.GetUploadImageSrc = function (str) {
            return Forguncy.Helper.SpecialPath.getBaseUrl() + "Upload/" + str;
        };
        return FileHelper;
    }());
    ElementCellTypes.FileHelper = FileHelper;
})(ElementCellTypes || (ElementCellTypes = {}));
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var DatePickerCellType = /** @class */ (function (_super) {
        __extends(DatePickerCellType, _super);
        function DatePickerCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DatePickerCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var separaterStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.datePickerRangeSeparater);
            var cellStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.datePickerCell);
            var self = this;
            this.addCustomClass("el-date-picker-custom");
            var cellType = this.cellType;
            var rangeTemplate = "\n:is-range=\"true\"\n:start-placeholder=\"startPlaceholder\"\n:end-placeholder=\"endPlaceholder\"\n";
            var isRange = cellType.type.indexOf("range") !== -1;
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var template = "\n<el-date-picker v-model=\"input\"\n:type=\"type\"\n:clearable=\"clearable\"\n:disabled=\"disabled\"\n:editable=\"editable\"\n:placeholder=\"placeholder\"\n:readonly=\"readOnly\"\n:format=\"format\"\n:prefix-icon=\"prefixIcon\"\npopper-class=\"".concat(popperClass, "\"\n:picker-options=\"pickerOptions\"\n").concat(cellType.type.indexOf("range") !== -1 ? rangeTemplate : "", "\n@change=\"handleChange\">\n    <template #range-separator v-if=\"type.indexOf('range') !== -1\">\n        ").concat(separaterStr || cellType.rangeSeparator, "\n    </template>\n    <template #default=\"cell\">\n        ").concat(cellStr, "\n    </template>\n</el-date-picker>\n");
            var option = {
                template: template,
                data: function () {
                    return {
                        input: null,
                        type: cellType.type,
                        clearable: this.boolConvertor(cellType.clearable),
                        disabled: cellType.IsDisabled,
                        editable: this.boolConvertor(cellType.editable),
                        format: this.getformat(),
                        placeholder: cellType.placeholder,
                        prefixIcon: "",
                        readOnly: undefined,
                        rangeSeparator: cellType.rangeSeparator,
                        startPlaceholder: cellType.startPlaceholder,
                        endPlaceholder: cellType.endPlaceholder,
                        pickerOptions: this.getPickerOptions()
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    getValue: function () {
                        if (!this.input) {
                            return null;
                        }
                        if (this.input.length) {
                            return this.input.map(Forguncy.ConvertDateToOADate).join(",");
                        }
                        return Forguncy.ConvertDateToOADate(this.input);
                    },
                    setValue: function (value) {
                        var covertValueToInput = function () {
                            if (!value) {
                                return null;
                            }
                            if (typeof value === "number") {
                                return Forguncy.ConvertOADateToDate(value);
                            }
                            if (typeof value === "string") {
                                if (isRange) {
                                    var callbackfn = function (item) { return ElementCellTypes.DateUtil.ConvertToDate(item); };
                                    return value.split(",").map(callbackfn);
                                }
                                var numerValue = Number(value);
                                return isNaN(numerValue) ?
                                    new Date(value) :
                                    Forguncy.ConvertOADateToDate(numerValue);
                            }
                            return value;
                        };
                        this.input = covertValueToInput();
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readOnly = value;
                    },
                    boolConvertor: function (value) {
                        return value ? true : false;
                    },
                    getPickerOptions: function () {
                        return {
                            firstDayOfWeek: cellType.firstDayOfWeek + 0
                        };
                    },
                    getformat: function () {
                        var _a, _b;
                        var format;
                        if (!((_b = (_a = cellType === null || cellType === void 0 ? void 0 : cellType.format) === null || _a === void 0 ? void 0 : _a.trim()) === null || _b === void 0 ? void 0 : _b.length) && cellType.type === "week") {
                            format = cellType.DefautWeekFormat;
                        }
                        else {
                            format = cellType.format;
                        }
                        return format === null || format === void 0 ? void 0 : format.replace("WW", "ww").replace("yyyy", "YYYY").replace("dd", "DD");
                    },
                    isInvalidDate: function (value) {
                        if (!(value instanceof Date)) {
                            return true;
                        }
                        return isNaN(value.getTime());
                    }
                },
                created: function () {
                    ElementUtils.Dayjs.toggleLocale({ weekStart: cellType.firstDayOfWeek });
                },
                mounted: function () {
                    self.fontDom = $('input', self.vueContainer)
                        .add(".el-date-editor", self.vueContainer);
                },
                watch: {
                    input: function (value) {
                        var isInvalidDate = this.isInvalidDate;
                        var getLegalValue = function () {
                            if (!value) {
                                return null;
                            }
                            if (!isRange) {
                                return isInvalidDate(value) ? null : value;
                            }
                            if (!(value instanceof Array)) {
                                return [];
                            }
                            if (isInvalidDate(value[0]) || isInvalidDate(value[1])) {
                                return [];
                            }
                            return value;
                        };
                        var legalValue = getLegalValue();
                        if (legalValue !== value) {
                            this.input = legalValue;
                        }
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.prefixIcon, function (icon) { return _this.vue.prefixIcon = icon; });
        };
        DatePickerCellType.prototype.GetSelectedRange = function () {
            var value = this.vue.input;
            var _a = value || [], startDate = _a[0], endDate = _a[1];
            return {
                StartValue: startDate,
                EndValue: endDate,
            };
        };
        return DatePickerCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.DatePickerCellType = DatePickerCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.DatePickerCellType, ElementUI", ElementCellTypes.DatePickerCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var InputCellType = /** @class */ (function (_super) {
        __extends(InputCellType, _super);
        function InputCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            this.addCustomClass("el-input-custom");
            var cellType = this.cellType;
            var option = {
                template: "\n<el-input v-model=\"input\"\n:type=\"type\" :maxlength=\"maxlength\" :show-word-limit=\"showWordLimit\" :readonly=\"readonly\"\n:placeholder=\"placeholder\" :clearable=\"clearable\" :showPassword=\"showPassword\" :resize=\"resize\"\nref=\"elInput\"\n:disabled=\"disabled\" :suffixIcon=\"suffixIcon\" :prefixIcon=\"prefixIcon\"\n@blur=\"handleBlur\"\n@change=\"handleChange\">\n</el-input>\n",
                data: function () {
                    return {
                        input: null,
                        type: cellType.type === "password" ? "text" : cellType.type,
                        maxlength: self.getMaxLength(),
                        showWordLimit: cellType.showWordLimit,
                        placeholder: cellType.placeholder,
                        clearable: cellType.clearable,
                        showPassword: cellType.type === "password",
                        disabled: cellType.IsDisabled,
                        prefixIcon: "",
                        suffixIcon: "",
                        readonly: undefined,
                        resize: cellType.resize,
                    };
                },
                methods: {
                    handleBlur: function () {
                        self.validate();
                    },
                    handleChange: function () {
                        self.commitValue();
                    },
                    getValue: function () {
                        return this.input;
                    },
                    setValue: function (value) {
                        this.input = value;
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                },
                mounted: function () {
                    var _a, _b, _c;
                    var refs = (_b = (_a = this.$refs) === null || _a === void 0 ? void 0 : _a.elInput) === null || _b === void 0 ? void 0 : _b.$refs;
                    var input = (_c = refs === null || refs === void 0 ? void 0 : refs.input) !== null && _c !== void 0 ? _c : refs === null || refs === void 0 ? void 0 : refs.textarea;
                    if (input) {
                        var inputJqel = $(input);
                        self.fontDom = inputJqel;
                        if (cellType.type !== "textarea") {
                            Forguncy.FocusMoveHelper.AllowMoveFocusByEnterKey(inputJqel, false);
                        }
                    }
                }
            };
            this.createVueApp(option);
            this.onDependenceCellValueChanged(function () {
                if (_this.isFormula(cellType.maxlength)) {
                    _this.vue.maxlength = _this.getMaxLength();
                }
            });
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.prefixIcon, function (icon) { return _this.vue.prefixIcon = icon; });
            _super.prototype.getIconComponent.call(this, cellType.suffixIcon, function (icon) { return _this.vue.suffixIcon = icon; });
        };
        InputCellType.prototype.getMaxLength = function () {
            var maxLength = this.CellElement.CellType.maxlength;
            var value = this.calcNumber(maxLength);
            if (isNaN(value) || value < 1) {
                return null;
            }
            return value;
        };
        InputCellType.prototype.Focus = function () {
            this.vue.$refs.elInput.focus();
        };
        InputCellType.prototype.Select = function () {
            this.vue.$refs.elInput.select();
        };
        return InputCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.InputCellType = InputCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.InputCellType, ElementUI", ElementCellTypes.InputCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var InputNumberCellType = /** @class */ (function (_super) {
        __extends(InputNumberCellType, _super);
        function InputNumberCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputNumberCellType.prototype.setValueToElement = function (jelement, value) {
            var _a;
            if (value === null) {
                return (_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue(undefined);
            }
            return _super.prototype.setValueToElement.call(this, jelement, value);
        };
        InputNumberCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            this.addCustomClass("el-input-number-custom");
            if (cellType.controlsPosition) {
                this.addCustomClass("el-input-number-custom-right");
            }
            var option = {
                template: "\n<el-input-number v-model=\"input\"\n:min=\"min\" :max=\"max\" :step=\"step\" :step-strictly=\"stepStrictly\" :precision=\"precision\" :disabled=\"disabled\"\n:controls-position=\"controlsPosition\" :placeholder=\"placeholder\" :controls=\"controls\"\n@blur=\"blurHandler\"\n@change=\"changedHandler\"\nref=\"elInput\"\n>\n</el-input-number>\n",
                data: function () {
                    return {
                        input: undefined,
                        min: self.calcNumber(cellType.min),
                        max: self.calcNumber(cellType.max),
                        step: self.calcNumber(cellType.step),
                        stepStrictly: cellType.stepStrictly,
                        precision: cellType.precision,
                        disabled: cellType.IsDisabled,
                        controlsPosition: cellType.controlsPosition === true ? "right" : "",
                        placeholder: cellType.placeholder,
                        controls: cellType.controls ? true : false,
                    };
                },
                methods: {
                    getValue: function () {
                        return this.input;
                    },
                    setValue: function (value) {
                        if (value !== null && value !== undefined && value !== "") {
                            this.input = Number(value);
                        }
                        else {
                            this.input = undefined;
                        }
                        if (self.isEmpty(self.inputValue)) {
                            self.inputValue = this.input;
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    blurHandler: function () {
                        self.validate();
                    },
                    changedHandler: function () {
                        self.validate();
                    }
                },
                mounted: function () {
                    var _this = this;
                    var inputJqel = $("input", self.vueContainer);
                    self.fontDom = inputJqel;
                    inputJqel.on("input", function () {
                        self.inputValue = inputJqel.val();
                    });
                    inputJqel.on("blur", function () {
                        if (self.inputValue === "") {
                            _this.input = undefined;
                        }
                    });
                    Forguncy.FocusMoveHelper.AllowMoveFocusByEnterKey(inputJqel, false);
                },
                watch: {
                    input: function (value) {
                        if (!this.stepStrictly) {
                            self.commitValue();
                            return;
                        }
                        if (value % this.step === 0) {
                            self.commitValue();
                        }
                    }
                }
            };
            this.createVueApp(option);
            this.onDependenceCellValueChanged(function () {
                if (_this.isFormula(cellType.min)) {
                    _this.vue.min = _this.calcNumber(cellType.min);
                }
                if (_this.isFormula(cellType.max)) {
                    _this.vue.max = _this.calcNumber(cellType.max);
                }
                if (_this.isFormula(cellType.step)) {
                    _this.vue.step = _this.calcNumber(cellType.step);
                }
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        InputNumberCellType.prototype.SetMinValue = function (value) {
            this.vue.min = Number(value);
        };
        InputNumberCellType.prototype.SetMaxValue = function (value) {
            this.vue.max = Number(value);
        };
        InputNumberCellType.prototype.SetStep = function (value) {
            this.vue.step = Number(value);
        };
        InputNumberCellType.prototype.Focus = function () {
            this.vue.$refs.elInput.focus();
        };
        return InputNumberCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.InputNumberCellType = InputNumberCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.InputNumberCellType, ElementUI", ElementCellTypes.InputNumberCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var Page = Forguncy.Page;
    var scrollTopData = {};
    var NavMenuCellType = /** @class */ (function (_super) {
        __extends(NavMenuCellType, _super);
        function NavMenuCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._pageName = _this.IsInMasterPage ? Page.getMasterPageName() : Page.getPageName();
            _this._scrollBarDataKey = "".concat(_this._pageName, "_").concat(_this.ID);
            _this._firstRender = true;
            return _this;
        }
        NavMenuCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        NavMenuCellType.prototype.generateIndex = function (options, parentIndex) {
            var _this = this;
            if (parentIndex === void 0) { parentIndex = null; }
            return options.map(function (option, index) {
                var _a;
                var key = parentIndex !== null ? "".concat(parentIndex, "-").concat(index) : index.toString();
                if ((_a = option === null || option === void 0 ? void 0 : option.children) === null || _a === void 0 ? void 0 : _a.length) {
                    option.children = _this.generateIndex(option.children, key);
                }
                return __assign(__assign({}, option), { index: key });
            });
        };
        NavMenuCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            this.addCustomClass("el-menu-custom");
            var self = this;
            var cellType = this.cellType;
            var CssClassName = this.CellElement.CssClassName;
            var options = [];
            var flatOptions = [];
            var openeds = new Set();
            var defaultOpeneds = [];
            var isVertical = cellType.mode === "vertical";
            if (!cellType.useBinding && cellType.options) {
                options = this.generateIndex(cellType.options);
                flatOptions = ElementCellTypes.TreeHelper.flat(options);
                NavMenuCellType.recalcNotice(options, this);
                if (isVertical) {
                    defaultOpeneds = this.getDefaultOpeneds(cellType.options);
                    defaultOpeneds.forEach(function (index) { return openeds.add(index); });
                }
            }
            this.addCustomClass(cellType.mode + "-menu");
            var intervalTimer = null;
            var timeoutTimer = null;
            var clearTimers = function () {
                clearInterval(intervalTimer);
                clearInterval(timeoutTimer);
            };
            var subMenuPopperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var contentStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.menuItemContent);
            var menuItemOption = {
                name: "menu-item",
                template: "\n                    <el-menu-item :index=\"item.index\" :key=\"item.value\">\n                        ".concat(contentStr || self.getDefaultMenuItemSlot(), "\n                    </el-menu-item>\n                "),
                props: {
                    item: Object,
                },
            };
            var subMenuOption = {
                name: "sub-menu",
                template: "\n                    <el-sub-menu :index=\"item.index\" :key=\"item.value\" popper-class=\"".concat(subMenuPopperClass, "\" @click.stop=\"handleClick(item.index)\">\n                        <template #title>\n                           <el-icon  v-if=\"item.svgIcon\" v-html=\"item.svgIcon\" />\n                           <el-image v-if=\"item.iconSrc\" class=\"el-icon\" fit=\"contain\" :src=\"item.iconSrc\" />\n                           <span class=\"fgc-el-menu-transparent\">{{item.label}}</span>\n                           <el-badge :value=\"item.notice\" class=\"fgc-menu-badge-item\" />\n                        </template>\n                    \n                        <template v-for=\"subItem in item.children\">\n                            <sub-menu  v-if=\"subItem && subItem.children && subItem.children.length\" :item=\"subItem\"  @click.stop=\"handleClick(subItem.index)\"/>\n                            <menu-item v-else :item=\"subItem\" />\n                        </template>\n                    \n                    </el-sub-menu>\n                "),
                props: {
                    item: Object
                },
                components: {
                    "menu-item": menuItemOption,
                },
                methods: {
                    handleClick: function (index) {
                        this.$emit("handleClick", index);
                    }
                }
            };
            var option = {
                template: "\n<el-scrollbar>\n    <el-menu\n        v-if=\"options?.length\"\n        ref=\"menu\"\n        :mode=\"mode\"\n        :background-color=\"backgroundColor\"\n        :text-color=\"textColor\"\n        :active-text-color=\"activeTextColor\"\n        :default-openeds=\"defaultOpeneds\"\n        :default-active=\"defaultActive\"\n        :unique-opened=\"uniqueOpened\"\n        :collapse=\"collapse\"\n        :collapse-transition=\"collapseTransition\"\n        :menu-trigger=\"menuTrigger\"\n        :ellipsis=\"false\"\n        @select=\"handleSelect\"\n        @open=\"handleOpen\"\n        @close=\"handleClose\"\n    >\n        <template v-for=\"item in options\">\n            <sub-menu v-if=\"item?.children?.length\" :item=\"item\" @handleClick=\"handleClick\"/>\n            <menu-item v-else :item=\"item\" />\n        </template>\n    </el-menu>\n</el-scrollbar>\n",
                components: {
                    "sub-menu": subMenuOption,
                    "menu-item": menuItemOption,
                },
                data: function () {
                    var _a;
                    return {
                        defaultActive: null,
                        selectedValue: null,
                        selectedKey: null,
                        options: options,
                        mode: cellType.mode,
                        collapse: isVertical && !!cellType.collapse,
                        uniqueOpened: cellType.uniqueOpened,
                        menuTrigger: cellType.menuTrigger,
                        collapseTransition: !!cellType.collapseTransition,
                        backgroundColor: (_a = Forguncy.ConvertToCssColor(cellType.backgroundColor)) !== null && _a !== void 0 ? _a : "transparent",
                        textColor: Forguncy.ConvertToCssColor(cellType.textColor),
                        activeTextColor: Forguncy.ConvertToCssColor(cellType.activeTextColor),
                        defaultOpeneds: defaultOpeneds,
                        ellipsis: true,
                        openeds: openeds,
                        flatOptions: flatOptions
                    };
                },
                mounted: function () {
                    this.elMenuOnRendered();
                },
                watch: {
                    options: {
                        deep: true,
                        handler: function () {
                            this.flatOptions = ElementCellTypes.TreeHelper.flat(this.options);
                        }
                    }
                },
                methods: {
                    elMenuOnRendered: function () {
                        var _this = this;
                        if (!this.$refs.menu) {
                            return;
                        }
                        var scrollTop = function () {
                            var scrollBarElement = _this.getScrollBarElement();
                            if (scrollBarElement) {
                                scrollBarElement.scrollTop(scrollTopData[self._scrollBarDataKey]);
                                clearTimers();
                            }
                        };
                        if (!isVertical) {
                            $(".el-menu", self.vueContainer)[0].style.setProperty('--el-menu-item-height', (self.vueContainer.height() - 3) + "px");
                        }
                        timeoutTimer = setTimeout(clearTimers, 2000);
                        intervalTimer = setInterval(scrollTop, 50);
                    },
                    getScrollBarElement: function () {
                        return $(".el-scrollbar__wrap", $(this.$el));
                    },
                    setScrollTopValue: function () {
                        var _a;
                        scrollTopData[self._scrollBarDataKey] = (_a = this.getScrollBarElement()) === null || _a === void 0 ? void 0 : _a.scrollTop();
                    },
                    handleSelect: function (key) {
                        this.setScrollTopValue();
                        this.handleSelectInternal(key);
                    },
                    getNodeAndParentNode: function (index) {
                        var node;
                        var pNode;
                        var pNodeIndex = index.substring(0, index.lastIndexOf("-"));
                        this.flatOptions.forEach(function (option) {
                            if (option.index === index) {
                                node = option;
                                return;
                            }
                            if (option.index === pNodeIndex) {
                                pNode = option;
                            }
                        });
                        return { node: node, pNode: pNode };
                    },
                    handleClick: function (index) {
                        var _a = this.getNodeAndParentNode(index), node = _a.node, pNode = _a.pNode;
                        this.execClickCommand(node, pNode);
                    },
                    execClickCommand: function (node, pNode) {
                        var commands = cellType.ClickCommand;
                        var initValue = {};
                        if (commands === null || commands === void 0 ? void 0 : commands.ParamProperties) {
                            initValue[commands.ParamProperties["value"]] = node === null || node === void 0 ? void 0 : node.value;
                            initValue[commands.ParamProperties["label"]] = node === null || node === void 0 ? void 0 : node.label;
                            initValue[commands.ParamProperties["parentId"]] = pNode === null || pNode === void 0 ? void 0 : pNode.value;
                        }
                        self.executeCustomCommandObject(commands, initValue, "click");
                    },
                    handleSelectInternal: function (key, preventCommandExecution) {
                        if (preventCommandExecution === void 0) { preventCommandExecution = false; }
                        this.selectedKey = key;
                        var _a = this.getNodeAndParentNode(key), node = _a.node, pNode = _a.pNode;
                        this.selectedValue = node === null || node === void 0 ? void 0 : node.value;
                        self.commitValue();
                        if (preventCommandExecution) {
                            return;
                        }
                        var commands = cellType.SelectCommand;
                        var initValue = {};
                        if (commands === null || commands === void 0 ? void 0 : commands.ParamProperties) {
                            initValue[commands.ParamProperties["value"]] = node === null || node === void 0 ? void 0 : node.value;
                            initValue[commands.ParamProperties["label"]] = node === null || node === void 0 ? void 0 : node.label;
                            initValue[commands.ParamProperties["parentId"]] = pNode === null || pNode === void 0 ? void 0 : pNode.value;
                        }
                        self.executeCustomCommandObject(commands, initValue, "select");
                        this.execClickCommand(node, pNode);
                    },
                    handleOpen: function (index) {
                        this.openeds.add(index);
                    },
                    handleClose: function (index) {
                        this.openeds.delete(index);
                    },
                    openMenuItem: function (index) {
                        this.handleOpen(index);
                        this.$refs.menu.open(index);
                    },
                    closeMenuItem: function (index) {
                        this.handleClose(index);
                        this.$refs.menu.close(index);
                    },
                    getNodeKey: function (value) {
                        var _a, _b;
                        return (_b = (_a = this.flatOptions) === null || _a === void 0 ? void 0 : _a.find(function (option) { return option.value === value; })) === null || _b === void 0 ? void 0 : _b.index;
                    },
                    getValue: function () {
                        return this.selectedValue;
                    },
                    setValue: function (value) {
                        var key = this.getNodeKey(value);
                        if (key) {
                            this.handleSelectInternal(key, true);
                        }
                        this.defaultActive = key;
                    },
                    setOptions: function (options) {
                        var _this = this;
                        var optionsTree = self.generateIndex(options ? ElementCellTypes.TreeHelper.build(options) : []);
                        var isExpand = !cellType.uniqueOpened && cellType.DefaultExpansion === "expand" && isVertical;
                        var flatOptions = ElementCellTypes.TreeHelper.flat(optionsTree);
                        var _firstRender = self._firstRender;
                        if (_firstRender && isExpand) {
                            self._firstRender = false;
                            var defaultOpeneds_1 = [];
                            flatOptions.forEach(function (option) {
                                var _a;
                                if ((_a = option === null || option === void 0 ? void 0 : option.children) === null || _a === void 0 ? void 0 : _a.length) {
                                    defaultOpeneds_1.push(option.index);
                                }
                            });
                            this.defaultOpeneds = defaultOpeneds_1;
                            defaultOpeneds_1.forEach(function (index) { return _this.openeds.add(index); });
                        }
                        if (!isVertical) {
                            this.ellipsis = false;
                        }
                        else if (!_firstRender) {
                            document.documentElement.style.setProperty('--el-transition-duration', "0s");
                        }
                        this.options = optionsTree;
                        this.flatOptions = flatOptions;
                        /**
                         * 这是Element的bug
                         * bug表现： 不管容器宽度有多宽，只会显示两个menu，其余都会被隐藏
                         */
                        if (!isVertical) {
                            this.$nextTick(function () { return _this.ellipsis = true; });
                        }
                        else {
                            if (_firstRender) {
                                this.elMenuOnRendered();
                            }
                            else if (isExpand) {
                                this.$nextTick(function () {
                                    flatOptions.forEach(function (option) { var _a, _b; return ((_a = option === null || option === void 0 ? void 0 : option.children) === null || _a === void 0 ? void 0 : _a.length) && ((_b = _this.$refs) === null || _b === void 0 ? void 0 : _b.menu.open(option.index)); });
                                    _this.$nextTick(function () {
                                        document.documentElement.style.setProperty('--el-transition-duration', "0.3s");
                                    });
                                });
                            }
                        }
                        NavMenuCellType.recalcIcon(this.options, self);
                    },
                    setCollapse: function (collapse) {
                        var _this = this;
                        if (collapse) {
                            if (cellType.collapseTransition) {
                                var openeds_1 = this.options.filter(function (option) { return _this.openeds.has(option.index); });
                                var timeout = openeds_1.length ? 300 : 0;
                                openeds_1.forEach(function (_a) {
                                    var index = _a.index;
                                    return _this.closeMenuItem(index);
                                });
                                setTimeout(function () {
                                    $(".fgc-el-menu-transparent", self.vueContainer).css("opacity", "0");
                                    _this.collapse = true;
                                }, timeout);
                            }
                            else {
                                this.collapse = true;
                            }
                        }
                        else {
                            this.collapse = false;
                        }
                    },
                    refreshNotice: function () {
                        NavMenuCellType.recalcNotice(this.options, self);
                    }
                },
                beforeDestroy: function () {
                    clearTimers();
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
            this.onDependenceCellValueChanged(function () {
                _this.vue.refreshNotice();
            });
            _super.prototype.onPageLoaded.call(this, info);
            NavMenuCellType.recalcIcon(this.vue.options, this);
        };
        NavMenuCellType.prototype.getDefaultMenuItemSlot = function () {
            return "\n            <el-icon  v-if=\"item.svgIcon\" v-html=\"item.svgIcon\" />\n            <el-image v-if=\"item.iconSrc\" class=\"el-icon\" fit=\"contain\" :src=\"item.iconSrc\" />\n            <template #title>\n                <span class=\"fgc-el-menu-transparent\">{{item.label}}</span>\n                <el-badge :value=\"item.notice\" class=\"fgc-menu-badge-item\" />\n            </template>";
        };
        NavMenuCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        NavMenuCellType.recalcNotice = function (option, cellType) {
            var nodes = ElementCellTypes.TreeHelper.flat(option);
            for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
                var node = nodes_1[_i];
                var menuNode = node;
                if (menuNode && menuNode.notification) {
                    var result = cellType.evaluateFormula(menuNode.notification);
                    if (result) {
                        menuNode.notice = result + "";
                    }
                    else {
                        menuNode.notice = "";
                    }
                }
            }
        };
        NavMenuCellType.recalcIcon = function (option, cellType) {
            var _a;
            var nodes = ElementCellTypes.TreeHelper.flat(option);
            var _loop_1 = function (node) {
                var menuNode = node;
                if (typeof (menuNode.icon) === "string") {
                    var src = menuNode.icon;
                    if (this_1.isAttachment(menuNode.icon)) {
                        src = Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer() + encodeURIComponent(menuNode.icon);
                    }
                    menuNode.iconSrc = src;
                }
                else {
                    if (menuNode && ((_a = menuNode.icon) === null || _a === void 0 ? void 0 : _a.Name)) {
                        cellType.getIcon(menuNode.icon, function (icon) {
                            if (icon.isSvg) {
                                menuNode.svgIcon = icon.icon;
                            }
                            else {
                                menuNode.iconSrc = icon.icon;
                            }
                        });
                    }
                }
            };
            var this_1 = this;
            for (var _i = 0, nodes_2 = nodes; _i < nodes_2.length; _i++) {
                var node = nodes_2[_i];
                _loop_1(node);
            }
        };
        NavMenuCellType.prototype.getDefaultOpeneds = function (option, baseIndex, result) {
            if (baseIndex === void 0) { baseIndex = ""; }
            if (result === void 0) { result = []; }
            for (var i = 0; i < (option === null || option === void 0 ? void 0 : option.length); i++) {
                var item = option[i];
                if (item === null || item === void 0 ? void 0 : item.children) {
                    if (item.expend) {
                        result.push(baseIndex + i);
                    }
                    this.getDefaultOpeneds(item.children, "".concat(baseIndex).concat(i, "-"), result);
                }
            }
            return result;
        };
        NavMenuCellType.getNodePath = function (key, options) {
            if (!key) {
                return null;
            }
            var keys = key.split("-");
            var node = options.find(function (option) { return option.index === keys[0]; });
            var index = keys[0];
            var nodes = [node];
            for (var i = 1; i < keys.length; i++) {
                index += "-" + keys[i];
                node = node.children.find(function (option) { return option.index === index; });
                nodes.push(node);
            }
            return nodes;
        };
        //RunTime Method
        NavMenuCellType.prototype.GetSelectPath = function (type) {
            var nullValue = {
                PathArray: null
            };
            var key = this.vue.selectedKey;
            if (!key) {
                var value = this.getValueFromDataModel();
                if (this.vue) {
                    key = this.vue.getNodeKey(value);
                }
                if (!key) {
                    return nullValue;
                }
            }
            var nodes = NavMenuCellType.getNodePath(key, this.vue.options);
            if (nodes) {
                if (type === "valuePath") {
                    return {
                        PathArray: nodes.map(function (i) { return i.value; })
                    };
                }
                else {
                    return {
                        PathArray: nodes.map(function (i) { return i.label; })
                    };
                }
            }
            return nullValue;
        };
        NavMenuCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        // RunTimeMethod
        NavMenuCellType.prototype.SetCollapse = function (collapse) {
            this.vue.setCollapse(collapse);
        };
        // RunTimeMethod
        NavMenuCellType.prototype.HideItems = function (items) {
            if (!items) {
                return;
            }
            var itemArray = items.split(',');
            var options = this.vue.options;
            this.HideItemsInternal(options, itemArray);
        };
        // RunTimeMethod
        NavMenuCellType.prototype.HideItemsInternal = function (options, hideArray) {
            if (!options) {
                return;
            }
            var _loop_2 = function (i) {
                var option = options[i];
                // 此处比较需要忽略类型，使用双等号
                // eslint-disable-next-line
                if (hideArray.find(function (value) { return option.value == value; })) {
                    options.splice(i, 1);
                }
                else {
                    this_2.HideItemsInternal(option.children, hideArray);
                }
            };
            var this_2 = this;
            for (var i = options.length - 1; i >= 0; i--) {
                _loop_2(i);
            }
        };
        // RunTimeMethod
        NavMenuCellType.prototype.SetBadge = function (itemValue, badgeValue) {
            this.SetBadgeInternal(this.vue.options, itemValue, badgeValue);
        };
        NavMenuCellType.prototype.SetBadgeInternal = function (options, itemValue, badgeValue) {
            if (!options) {
                return;
            }
            for (var i = options.length - 1; i >= 0; i--) {
                var option = options[i];
                // eslint-disable-next-line
                if (option.value == itemValue) {
                    option.notice = badgeValue === null || badgeValue === void 0 ? void 0 : badgeValue.toString();
                }
                this.SetBadgeInternal(option.children, itemValue, badgeValue);
            }
        };
        return NavMenuCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.NavMenuCellType = NavMenuCellType;
    var CellHelper = /** @class */ (function () {
        function CellHelper() {
        }
        CellHelper.setValueToCell = function (context, cellLocationFormula, value) {
            if (!cellLocationFormula) {
                return;
            }
            var cellLocation = Forguncy.Helper.getCellLocation(cellLocationFormula, context);
            var cell = Forguncy.Page.getCellByLocation(cellLocation);
            if (cell) {
                cell.setValue(value);
            }
            else {
                Forguncy.CommandHelper.setVariableValue(cellLocationFormula, value);
            }
        };
        return CellHelper;
    }());
    ElementCellTypes.CellHelper = CellHelper;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.NavMenuCellType, ElementUI", ElementCellTypes.NavMenuCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var PaginationCellType = /** @class */ (function (_super) {
        __extends(PaginationCellType, _super);
        function PaginationCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PaginationCellType.prototype.createContent = function () {
            var cellType = this.cellType;
            if (cellType.ListviewName) {
                Forguncy.ForguncyData.initListviewPaginationInfo(this.runTimePageName, cellType.ListviewName, cellType.pageSize);
            }
            return _super.prototype.createContent.call(this);
        };
        PaginationCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            var self = this;
            this.addCustomClass("el-pagination-custom");
            var cellType = this.cellType;
            if (cellType.ListviewName) {
                this._listview = Forguncy.Page.getListViews(true)
                    .filter(function (i) { return i.getName() === cellType.ListviewName && i.getRunTimePageName() === _this.runTimePageName; })[0];
            }
            var listview = this._listview;
            var option = {
                template: "<div class=\"fgc-pagination\">\n<el-pagination\n    :small=\"small\"\n    :background=\"background\"\n    :page-size=\"pageSize\"\n    :total=total\n    :pager-count=\"pagerCount\"\n    :layout=\"layout\"\n    :page-sizes=\"pageSizes\"\n    :prev-text=\"prevText\"\n    :next-text=\"nextText\"\n    :disabled=\"disabled\"\n    :hide-on-single-page=\"hideOnSinglePage\"\n    v-model:currentPage=\"currentPage\"\n\n    @size-change=\"onSizeChanged\"\n    @current-change=\"onCurrentChanged\"\n  >\n  </el-pagination>\n</div>",
                data: function () {
                    return {
                        small: cellType.small,
                        background: cellType.background,
                        pageSize: Number(cellType.pageSize),
                        total: 100,
                        pagerCount: cellType.pagerCount,
                        layout: cellType.layout.map(function (i) { return i.layoutItem; }).join(","),
                        pageSizes: cellType.pageSizes.map(function (i) { return i.value; }),
                        prevText: cellType.prevText,
                        nextText: cellType.nextText,
                        disabled: undefined,
                        currentPage: 0,
                        hideOnSinglePage: cellType.hideOnSinglePage,
                    };
                },
                methods: {
                    onSizeChanged: function (size) {
                        this.pageSize = size;
                        this.updateSize();
                        this.executeCommand();
                    },
                    onCurrentChanged: function () {
                        this.updatePage();
                        this.executeCommand();
                        self.commitValue();
                    },
                    executeCommand: function () {
                        var _a, _b;
                        if ((_b = (_a = cellType.PagingChangeCommands) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var commands = cellType.PagingChangeCommands;
                            var initParam = {};
                            initParam[commands.ParamProperties["pageSize"]] = this.pageSize;
                            initParam[commands.ParamProperties["currentPage"]] = this.currentPage;
                            initParam[commands.ParamProperties["total"]] = this.total;
                            self.executeCustomCommandObject(commands, initParam, "CurrentPageChangeCommands_" + self.ID);
                        }
                    },
                    setValue: function (value) {
                        var pageIndex = Math.max(1, Number(value));
                        if (Number.isNaN(pageIndex)) {
                            pageIndex = 1;
                        }
                        if (pageIndex !== this.currentPage) {
                            this.currentPage = pageIndex;
                            this.updatePage();
                        }
                    },
                    getValue: function () {
                        return this.currentPage;
                    },
                    updateSize: function () {
                        if (listview) {
                            listview.usePaginationDisplay(this.pageSize);
                        }
                    },
                    updatePage: function () {
                        if (listview) {
                            listview.goToSpecifiedPage(this.currentPage);
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    }
                },
                watch: {
                    pageSize: function (value) {
                        if (typeof value !== "number") {
                            var numerValue = Number(value);
                            this.value = isNaN(numerValue) ? null : numerValue;
                        }
                    }
                }
            };
            this.createVueApp(option);
            if (listview) {
                var currentInfo = listview.getPaginationInfo();
                this.vue.total = currentInfo === null || currentInfo === void 0 ? void 0 : currentInfo.TotalRowCount;
                this.vue.currentPage = currentInfo ? currentInfo.PageIndex : 1;
                this.vue.pageSize = (_a = currentInfo === null || currentInfo === void 0 ? void 0 : currentInfo.MaxRowCountOfOnePage) !== null && _a !== void 0 ? _a : this.vue.pageSize;
                this._pagingChangedCallBack = function (data, info) {
                    _this.vue.total = info.TotalRowCount;
                    _this.vue.currentPage = info.CurrentPageIndex;
                    _this.vue.pageSize = info.MaxRowCountOfOnePage;
                };
                listview.bind(Forguncy.ListViewEvents.PageingInfoChanged, this._pagingChangedCallBack);
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        PaginationCellType.prototype.destroy = function () {
            _super.prototype.destroy.call(this);
            if (this._listview) {
                this._listview.unbind(Forguncy.ListViewEvents.PageingInfoChanged, this._pagingChangedCallBack);
            }
        };
        // RunTimeMethods
        PaginationCellType.prototype.SetPageSize = function (pageSize) {
            pageSize = Number(pageSize);
            this.vue.pageSize = pageSize;
            this.vue.updateSize();
        };
        PaginationCellType.prototype.SetCurrentPageIndex = function (index) {
            index = Number(index);
            this.vue.currentPage = index;
            this.vue.updatePage();
        };
        PaginationCellType.prototype.SetTotal = function (total) {
            total = Number(total);
            this.vue.total = total;
            this.vue.updateSize();
        };
        PaginationCellType.prototype.ExecuteCommand = function () {
            this.vue.executeCommand();
        };
        return PaginationCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.PaginationCellType = PaginationCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.CellTypes.PaginationCellType, ElementUI", ElementCellTypes.PaginationCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var ProgressType;
    (function (ProgressType) {
        ProgressType[ProgressType["line"] = 0] = "line";
        ProgressType[ProgressType["circle"] = 1] = "circle";
        ProgressType[ProgressType["dashboard"] = 2] = "dashboard";
    })(ProgressType || (ProgressType = {}));
    var ProgressStatus;
    (function (ProgressStatus) {
        ProgressStatus[ProgressStatus["none"] = 0] = "none";
        ProgressStatus[ProgressStatus["success"] = 1] = "success";
        ProgressStatus[ProgressStatus["exception"] = 2] = "exception";
        ProgressStatus[ProgressStatus["warning"] = 3] = "warning";
    })(ProgressStatus || (ProgressStatus = {}));
    var ProgressCellType = /** @class */ (function (_super) {
        __extends(ProgressCellType, _super);
        function ProgressCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ProgressCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var containerId = "".concat(this.uId);
            var alignItems = cellType.type === ProgressType.line ? "" : "align-items:center";
            var option = {
                template: "<div class=\"fgc-el-progress\" style=\"".concat(alignItems, ";\">\n                              <el-progress\n                                  :percentage=\"percentage\"\n                                  :stroke-width=\"strokeWidth\"\n                                  :width=\"width\"\n                                  :type=\"type\"\n                                  :text-inside=\"textInside\"\n                                  :status=\"status\"\n                                  :color=\"color\"\n                                  :show-text=\"showText\"\n                                  :format=\"format\"\n                              />\n                        </div>\n                          "),
                data: function () {
                    return {
                        percentage: 0,
                        strokeWidth: cellType.strokeWidth,
                        width: 126,
                        showText: !!cellType.showText,
                        textInside: !!cellType.textInside && cellType.type === ProgressType.line,
                        type: ProgressType[cellType.type],
                        status: cellType.status === ProgressStatus.none ? null : ProgressStatus[cellType.status],
                        color: cellType.status === ProgressStatus.none ? Forguncy.ConvertToCssColor(cellType.color) : undefined,
                    };
                },
                mounted: function () {
                    var container = document.getElementById(containerId);
                    if (!container) {
                        return;
                    }
                    var height = container.offsetHeight, width = container.offsetWidth;
                    if (this.type !== ProgressType[ProgressType.line]) {
                        this.width = Math.min(width, height);
                    }
                    self.fontDom = $(".el-progress__text,.el-progress-bar__innerText", self.getContainer()).find("span");
                },
                methods: {
                    getValue: function () {
                        return this.percentage;
                    },
                    setValue: function (value) {
                        this.percentage = Number(value);
                    },
                    format: function (percentage) {
                        if (cellType.textFormula) {
                            return self.evaluateFormula(cellType.textFormula);
                        }
                        return percentage + "%";
                    }
                }
            };
            this.createVueApp(option);
            this.onDependenceCellValueChanged(function () {
                if (_this.isFormula(cellType.textFormula)) {
                    var old_1 = _this.vue.percentage;
                    _this.vue.percentage = old_1 + 1;
                    // 强行触发一次percentage change，否则的话format方法不走
                    setTimeout(function () {
                        _this.vue.percentage = old_1;
                    });
                }
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        ProgressCellType.prototype.clickable = function () {
            return false;
        };
        ProgressCellType.prototype.SetBackgroundColor = function (color) {
            this.vue.status = null;
            this.vue.color = Forguncy.ConvertToCssColor(color);
        };
        ProgressCellType.prototype.SetStatus = function (status) {
            var newStatus = status === ProgressStatus.none ? null : ProgressStatus[status];
            if (newStatus) {
                this.vue.color = undefined;
            }
            this.vue.status = newStatus;
        };
        return ProgressCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.ProgressCellType = ProgressCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.ProgressCellType, ElementUI", ElementCellTypes.ProgressCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var RateDisplayContentType;
    (function (RateDisplayContentType) {
        RateDisplayContentType[RateDisplayContentType["None"] = 0] = "None";
        RateDisplayContentType[RateDisplayContentType["Text"] = 1] = "Text";
        RateDisplayContentType[RateDisplayContentType["Scope"] = 2] = "Scope";
    })(RateDisplayContentType || (RateDisplayContentType = {}));
    var RateCellType = /** @class */ (function (_super) {
        __extends(RateCellType, _super);
        function RateCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        RateCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            var self = this;
            var DisplayContentType = cellType.DisplayContentType;
            var option = {
                template: "\n                        <div style=\"display:flex;align-items:center;width:100%;height:100%\">\n                            <el-rate\n                                v-model=\"value\"\n                                :max=\"max\"\n                                :disabled=\"disabled\"\n                                :show-text=\"showText\"\n                                :show-score=\"showScore\"\n                                :texts=\"texts\"\n                                :colors=\"colors\"\n                                :void-color=\"voidColor\"\n                                :disabled-void-color=\"disabledVoidColor\t\"\n                                :allow-half=\"allowHalf\"\n                                :low-threshold=\"lowThreshold\"\n                                :high-threshold=\"highThreshold\"\n                                @change=\"handleChange\"\n                           />\n                       </div>\n                          ",
                data: function () {
                    var _a, _b;
                    return {
                        value: null,
                        max: cellType.max,
                        disabled: undefined,
                        allowHalf: cellType.allowHalf,
                        lowThreshold: cellType.lowThreshold,
                        highThreshold: cellType.highThreshold,
                        voidColor: Forguncy.ConvertToCssColor(cellType.voidColor),
                        disabledVoidColor: Forguncy.ConvertToCssColor(cellType.disabledVoidColor),
                        texts: (_a = cellType.texts) === null || _a === void 0 ? void 0 : _a.map(function (_a) {
                            var label = _a.label;
                            return label;
                        }),
                        colors: (_b = cellType.colors) === null || _b === void 0 ? void 0 : _b.map(function (_a) {
                            var color = _a.color;
                            return Forguncy.ConvertToCssColor(color);
                        }),
                        showText: DisplayContentType === RateDisplayContentType.Text,
                        showScore: DisplayContentType === RateDisplayContentType.Scope,
                    };
                },
                mounted: function () {
                    self.fontDom = $(".el-rate__text", self.getContainer());
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        this.value = Math.min(value, this.max);
                    },
                    setReadOnly: function (readOnly) {
                        this.disabled = readOnly;
                    },
                    handleChange: function () {
                        self.commitValue();
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        RateCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.refreshClickable();
        };
        RateCellType.prototype.refreshClickable = function () {
            var _a, _b;
            if ((_a = this.vue) === null || _a === void 0 ? void 0 : _a.$el) {
                (_b = $(this.vue.$el).parent()) === null || _b === void 0 ? void 0 : _b.attr("clickable", this.clickable() ? true : "");
            }
        };
        RateCellType.prototype.clickable = function () {
            return !this.isReadOnly() && !this.isDisabled();
        };
        return RateCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.RateCellType = RateCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.RateCellType, ElementUI", ElementCellTypes.RateCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var SelectCellType = /** @class */ (function (_super) {
        __extends(SelectCellType, _super);
        function SelectCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.defaultQueryDataOption = {
                top: _this.cellType.filterInServerOptions.defaultMaxOptionsCount,
                queryConditions: [],
                distinct: true
            };
            return _this;
        }
        SelectCellType.prototype.setDataSource = function (dataSource) {
            var _a;
            var cloneDataSource = __spreadArray([], dataSource, true);
            if (this.cellType.AllowAddEmptyItem) {
                var label = (_a = this.cellType.EmptyItemLabel) !== null && _a !== void 0 ? _a : "";
                if (!label) {
                    this.vue.placeholder = null;
                }
                /**
                 * Element Plus 不接受一个null,会报 warning
                 */
                cloneDataSource.unshift({ value: "", label: label });
            }
            return this.vue.setOptions(cloneDataSource);
        };
        SelectCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            var optionStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.selectOption);
            var prefixStr = this.getCustomSlotByPath(ElementCellTypes.SlotPath.selectPrefix);
            var self = this;
            var styleInfo = (_a = this._cellStyle) !== null && _a !== void 0 ? _a : {};
            var fontSize = styleInfo.FontSize && styleInfo.FontSize > 0 ? styleInfo.FontSize : "";
            var cellType = this.cellType;
            this.addCustomClass("el-select-custom");
            var options = [];
            if (cellType.options && !cellType.useBinding) {
                options = cellType.options.map(function (o) { var _a; return (__assign(__assign({}, o), { value: (_a = o.value) !== null && _a !== void 0 ? _a : "" })); });
            }
            var remoteFilterBinding = '';
            if (cellType.useBinding && cellType.filterInServer) {
                remoteFilterBinding = ':remote-method="remoteMethod"';
            }
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var option = {
                template: "\n<el-select\n    v-model=\"value\"\n    :placeholder=\"placeholder\"\n    :disabled = \"disabled\"\n    :clearable= \"clearable\"\n    :collapse-tags = \"collapseTags\"\n    :filterable = \"filterable\"\n    :multiple = \"multiple\"\n    :allow-create = \"allowCreate\"\n    :reserve-keyword = \"reserveKeyword\"\n    :multiple-limit = \"multipleLimit\"\n    :no-match-text = \"noMatchText\"\n    :no-data-text = \"noDataText\"\n    :remote=\"filterInServer\"\n    popper-class=\"".concat(popperClass, "\"\n    ").concat(remoteFilterBinding, "\n    :loading-text=\"loadingText\"\n    :loading=\"loading\"\n    default-first-option\n    ref=\"elInput\"\n    @change=\"handleChange\" style=\"height:100%;width:100%\">\n        <el-option\n              style=\"font-size:").concat(fontSize, "px;\"\n              v-for=\"option in options\"\n              :key=\"option.value\"\n              :label=\"option.label\"\n              :value=\"option.value\"\n        >\n            ").concat(optionStr, "\n        </el-option>\n        ").concat(prefixStr ? "<template #prefix>" + prefixStr + "</template>" : "", "\n    </el-select>\n"),
                data: function () {
                    return {
                        disabled: cellType.IsDisabled,
                        value: "",
                        options: options,
                        placeholder: cellType.placeholder,
                        clearable: cellType.clearable,
                        collapseTags: cellType.collapseTags,
                        filterable: cellType.filterable,
                        multiple: cellType.multiple,
                        allowCreate: cellType.allowCreate,
                        reserveKeyword: cellType.reserveKeyword,
                        multipleLimit: cellType.multipleLimit,
                        noMatchText: cellType.noMatchText,
                        noDataText: cellType.noDataText,
                        loading: false,
                        filterInServer: cellType.filterInServer,
                        loadingText: cellType.filterInServerOptions.loadingText,
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    getValue: function () {
                        if (cellType.multiple && this.value instanceof Array) {
                            return this.value.join(",");
                        }
                        return this.value;
                    },
                    setValue: function (value) {
                        this.setValueInternal(value, true);
                    },
                    setValueInternal: function (value, loadNotMathItems) {
                        if (loadNotMathItems === void 0) { loadNotMathItems = false; }
                        if (value) {
                            var arrayValue = void 0;
                            if (cellType.multiple) {
                                if (value instanceof Array) {
                                    arrayValue = value;
                                }
                                else {
                                    arrayValue = (value + "").split(",");
                                }
                            }
                            else {
                                arrayValue = [value];
                            }
                            var notMatchItems = this.updateValueByItems(arrayValue);
                            if (cellType.multiple) {
                                this.value = arrayValue;
                            }
                            else {
                                this.value = arrayValue[0];
                            }
                            if (loadNotMathItems) {
                                this.queryNotMatchItemsFromServer(notMatchItems);
                            }
                        }
                        else {
                            this.value = "";
                        }
                    },
                    queryNotMatchItemsFromServer: function (notMatchItems) {
                        var _this = this;
                        if (!notMatchItems || notMatchItems.length === 0) {
                            return;
                        }
                        if (cellType.filterInServer) {
                            var queryDataOption = {
                                queryConditions: [],
                                relationType: 1 /* Or */
                            };
                            for (var _i = 0, notMatchItems_1 = notMatchItems; _i < notMatchItems_1.length; _i++) {
                                var notMatchItem = notMatchItems_1[_i];
                                queryDataOption.queryConditions.push({
                                    columnName: "value",
                                    compareType: 0 /* EqualsTo */,
                                    compareValue: notMatchItem
                                });
                            }
                            self.getBindingDataSourceValue(cellType.bindingOptions, queryDataOption, function (newOptions) {
                                if (newOptions && newOptions.length > 0) {
                                    for (var _i = 0, newOptions_1 = newOptions; _i < newOptions_1.length; _i++) {
                                        var newOption = newOptions_1[_i];
                                        _this.options.push(newOption);
                                    }
                                }
                                _this.setValueInternal(_this.value);
                            });
                        }
                    },
                    updateValueByItems: function (arrayValue) {
                        var notMatchItems = [];
                        if (this.options) {
                            for (var i = 0; i < arrayValue.length; i++) {
                                var value = arrayValue[i];
                                if (!value && value !== 0) {
                                    continue;
                                }
                                var match = false;
                                for (var _i = 0, _a = this.options; _i < _a.length; _i++) {
                                    var option_2 = _a[_i];
                                    if (option_2.value == value) {
                                        arrayValue[i] = option_2.value;
                                        match = true;
                                        break;
                                    }
                                }
                                if (!match) {
                                    notMatchItems.push(value);
                                }
                            }
                        }
                        return notMatchItems;
                    },
                    remoteMethod: function (query) {
                        var _this = this;
                        var queryDataOption = this.defaultQueryDataOption;
                        if (query) {
                            queryDataOption = {
                                queryConditions: [{
                                        columnName: "label",
                                        compareType: cellType.filterInServerOptions.matchMethod === "startWith" ?
                                            6 /* BeginsWith */ : 10 /* Contains */,
                                        compareValue: query + ""
                                    }],
                                distinct: true,
                                top: cellType.filterInServerOptions.maxFilterResultCount
                            };
                        }
                        this.loading = true;
                        ElementCellTypes.SupportDataSourceCellType.refreshDataWithOption(self, cellType.bindingOptions, function (dataSource) {
                            self.setDataSource(dataSource);
                            _this.loading = false;
                        }, queryDataOption, false);
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setOptions: function (options) {
                        if (options) {
                            this.options = options.map(function (o) { var _a; return (__assign(__assign({}, o), { value: (_a = o.value) !== null && _a !== void 0 ? _a : "" })); });
                        }
                        else {
                            this.options = [];
                        }
                    }
                },
                mounted: function () {
                    var input = $("input", $(this.$el));
                    if (input.length > 0) {
                        self.fontDom = input;
                        self.setFontToDom();
                    }
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                if (cellType.filterable && cellType.filterInServer) {
                    ElementCellTypes.SupportDataSourceCellType.refreshDataWithOption(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); }, this.defaultQueryDataOption);
                }
                else {
                    self.ReloadBindingItems();
                }
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        SelectCellType.prototype.getSelectedItem = function () {
            var _a = this.vue, value = _a.value, options = _a.options;
            var filterHandler;
            if (value instanceof Array) {
                filterHandler = function (option) { return value.includes(option.value); };
            }
            else {
                filterHandler = function (option) { return value === option.value; };
            }
            return options.filter(filterHandler);
        };
        SelectCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.CellElement.CellType;
            ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); }, {
                distinct: true
            });
        };
        SelectCellType.prototype.reload = function () {
            if (this.cellType.useBinding) {
                this.ReloadBindingItems();
            }
        };
        SelectCellType.prototype.SetDataSourceByStringArray = function (dataSource) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var objSource = dataSource.map(function (i) { return ({
                "value": i,
                "label": i,
            }); });
            this.setDataSource(objSource);
        };
        SelectCellType.prototype.SetDataSourceByObjArray = function (dataSource, valueProperty, labelProperty) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (!labelProperty) {
                labelProperty = valueProperty;
            }
            var objSource = dataSource.map(function (i) { return (__assign(__assign({}, i), { "value": i[valueProperty], "label": i[labelProperty] })); });
            this.setDataSource(objSource);
        };
        SelectCellType.prototype.Focus = function () {
            this.vue.$refs.elInput.focus();
        };
        SelectCellType.prototype.GetSelectedText = function () {
            return {
                SelectedText: this.getSelectedItem().map(function (item) { return item.label; }).join(",")
            };
        };
        return SelectCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.SelectCellType = SelectCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.SelectCellType, ElementUI", ElementCellTypes.SelectCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var SliderCellType = /** @class */ (function (_super) {
        __extends(SliderCellType, _super);
        function SliderCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SliderCellType.prototype.convertToObjectMarks = function (marks) {
            return marks.reduce(function (obj, item) { return (obj[item.Value] = item.Label, obj); }, {});
        };
        SliderCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var isVertical = cellType.layout === "vertical";
            this.getContainer().css("overflow", "");
            var marks = this.convertToObjectMarks(cellType.Marks);
            var option = {
                template: "<div id=\"".concat(this.uId, "-el-slider\" :class=\"['fgc-slider', 'hasMarks',{ 'is-vertical': vertical }]\">\n                               <el-slider\n                                   v-model=\"value\" :min=\"min\" :max=\"max\" :disabled=\"disabled\" :showTooltip=\"showTooltip\"\n                                   :step=\"step\" :show-input=\"showInput\" :show-input-controls=\"showInputControls\"\n                                   :show-stops=\"showStops\" :range=\"range\" :vertical=\"vertical\" :height=\"height\"\n                                   :formatTooltip=\"formatTooltip\" :marks=\"marks\"\n                                   @change=\"handleChange\"\n                               />\n                            </div> \n                          "),
                data: function () {
                    return {
                        value: null,
                        height: null,
                        min: self.calcNumber(cellType.min),
                        max: self.calcNumber(cellType.max),
                        disabled: undefined,
                        step: self.calcNumber(cellType.step),
                        showTooltip: !!cellType.showTooltip,
                        showInput: cellType.showInput,
                        showInputControls: !!cellType.showInputControls,
                        showStops: cellType.showStops,
                        range: cellType.range,
                        vertical: isVertical,
                        marks: marks
                    };
                },
                mounted: function () {
                    if (this.vertical) {
                        var element = document.getElementById("".concat(self.uId, "-el-slider"));
                        var height = (element.offsetHeight - 24) - (this.showInput ? 58 : 0);
                        this.height = "".concat(height, "px");
                    }
                },
                methods: {
                    getValue: function () {
                        if (Array.isArray(this.value)) {
                            return this.value.join(",");
                        }
                        return this.value;
                    },
                    setValue: function (value) {
                        if (self.isEmpty(value)) {
                            this.value = undefined;
                        }
                        else if (typeof value === "number") {
                            this.value = value;
                        }
                        else if (typeof value === "string") {
                            this.value = value.indexOf(',') !== -1 ?
                                value.split(",").map(function (i) { return Number(i); }) :
                                Number(value);
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    handleChange: function () {
                        self.commitValue();
                    },
                    formatTooltip: function (value) {
                        if (cellType.formatTooltipStr) {
                            self.setContextVariableValue("Value", value);
                            try {
                                return self.evaluateFormula(cellType.formatTooltipStr);
                            }
                            finally {
                                self.clearContextVariableValue("Value");
                            }
                        }
                        return value;
                    }
                }
            };
            this.onDependenceCellValueChanged(function () {
                if (_this.isFormula(cellType.min)) {
                    _this.vue.min = _this.calcNumber(cellType.min);
                }
                if (_this.isFormula(cellType.max)) {
                    _this.vue.max = _this.calcNumber(cellType.max);
                }
                if (_this.isFormula(cellType.step)) {
                    _this.vue.step = _this.calcNumber(cellType.step);
                }
            });
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        SliderCellType.prototype.SetMinValue = function (value) {
            this.vue.min = Number(value);
        };
        SliderCellType.prototype.SetMaxValue = function (value) {
            this.vue.max = Number(value);
        };
        SliderCellType.prototype.SetMarks = function (marks) {
            this.vue.marks = this.convertToObjectMarks((marks === null || marks === void 0 ? void 0 : marks.$values) || []);
        };
        SliderCellType.prototype.GetSelectedRange = function () {
            var value = this.vue.value;
            if (value instanceof Array) {
                return {
                    StartValue: value[0],
                    EndValue: value[1]
                };
            }
            return {};
        };
        return SliderCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.SliderCellType = SliderCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.SliderCellType, ElementUI", ElementCellTypes.SliderCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var StepsStatus;
    (function (StepsStatus) {
        StepsStatus[StepsStatus["wait"] = 0] = "wait";
        StepsStatus[StepsStatus["process"] = 1] = "process";
        StepsStatus[StepsStatus["finish"] = 2] = "finish";
        StepsStatus[StepsStatus["error"] = 3] = "error";
        StepsStatus[StepsStatus["success"] = 4] = "success";
    })(StepsStatus || (StepsStatus = {}));
    var StepsCellType = /** @class */ (function (_super) {
        __extends(StepsCellType, _super);
        function StepsCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        StepsCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        StepsCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var containerId = "".concat(this.uId, "-el-steps");
            this.addCustomClass("el-steps-custom");
            var option = {
                el: "#" + this.uId,
                template: "<div id=\"".concat(containerId, "\" style=\"width: 100%;height: 100%;\">\n                                 <el-steps \n                                     :active=\"active\" \n                                     :direction=\"direction\" \n                                     :simple=\"simple\" \n                                     :align-center=\"alignCenter\" \n                                     :process-status=\"processStatus\"\n                                     :finish-status=\"finishStatus\"\n                                 > \n                                    <el-step \n                                        v-for=\"item in options\" \n                                        :key=\"item.title\" \n                                        :title=\"item.title\" \n                                        :icon=\"item.iconComponent\" \n                                        :description=\"item.description\" \n                                    />\n                                 </el-steps>\n                            </div>\n                          "),
                data: function () {
                    return {
                        active: -1,
                        value: null,
                        options: cellType.useBinding ? [] : cellType.options,
                        simple: cellType.simple && cellType.layout === "horizontal",
                        alignCenter: cellType.alignCenter,
                        direction: cellType.layout,
                        processStatus: StepsStatus[cellType.processStatus],
                        finishStatus: StepsStatus[cellType.finishStatus],
                    };
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        this.value = value;
                        this.updateActive();
                    },
                    setOptions: function (options) {
                        this.options = options;
                        this.updateActive();
                        self.recalcIcon();
                    },
                    updateActive: function () {
                        var _a, _b;
                        if ((_a = this.options) === null || _a === void 0 ? void 0 : _a.length) {
                            for (var i = 0; i < this.options.length; i++) {
                                var option_3 = this.options[i];
                                // 这里认为字符串数字与数字等价，双等号不能去掉
                                // eslint-disable-next-line
                                if (option_3.value == this.value) {
                                    this.active = i;
                                    return;
                                }
                            }
                        }
                        if (this.value || this.value === 0) {
                            this.active = (_b = this.options) === null || _b === void 0 ? void 0 : _b.length;
                        }
                        else {
                            this.active = -1;
                        }
                    }
                }
            };
            this.createVueApp(option);
            self.recalcIcon();
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        StepsCellType.prototype.recalcIcon = function () {
            var _loop_3 = function (i) {
                var option = this_3.vue.options[i];
                var icon = option === null || option === void 0 ? void 0 : option.icon;
                this_3.getIconComponent(icon, function (icon) { return option.iconComponent = icon; });
            };
            var this_3 = this;
            for (var i = 0; i < this.vue.options.length; i++) {
                _loop_3(i);
            }
        };
        StepsCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        StepsCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        StepsCellType.prototype.UpdateProcessState = function (state) {
            this.vue.processStatus = StepsStatus[state];
        };
        return StepsCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.StepsCellType = StepsCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.StepsCellType, ElementUI", ElementCellTypes.StepsCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var transitionDuration = 0.3;
    var setElTransitionDurationPropertyTimeOut = 0.3 * 1000;
    var TabHeaderCellType = /** @class */ (function (_super) {
        __extends(TabHeaderCellType, _super);
        function TabHeaderCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TabHeaderCellType.prototype.setElTransitionDurationProperty = function (delay) {
            if (delay === void 0) { delay = false; }
            var handler = function () { return document.documentElement.style.setProperty('--el-transition-duration', transitionDuration + "s"); };
            if (delay) {
                if (this._setElTransitionDurationPropertyTimer) {
                    clearTimeout(this._setElTransitionDurationPropertyTimer);
                }
                this._setElTransitionDurationPropertyTimer = setTimeout(handler, setElTransitionDurationPropertyTimeOut);
            }
            else {
                handler();
            }
        };
        TabHeaderCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var tabs = [];
            if (!cellType.useBinding && cellType.Tabs) {
                cellType.Tabs.every(function (i) { var _a; return i.ValueStr = (_a = i.Value) === null || _a === void 0 ? void 0 : _a.toString(); });
                tabs = cellType.Tabs;
            }
            this.addCustomClass("el-tabs-custom");
            var activeName = (cellType.DefaultIndex - 1).toString();
            var classStr = "fgc-" + cellType.type;
            var option = {
                template: "<el-tabs v-model=\"activeName\" class=\"".concat(classStr, "\" :type=\"type\" :stretch=\"stretch\" :tab-position=\"position\" @tab-click=\"ItemClick\">\n<template v-for=\"(tab,index) in tabs\">\n  <el-tab-pane :name=\"tab.ValueStr\" :label=\"tab.Name\"></el-tab-pane>\n</template>\n</el-tabs>"),
                data: function () {
                    return {
                        tabs: tabs,
                        activeName: activeName,
                        type: cellType.type === "default" ? undefined : cellType.type,
                        position: cellType.position,
                        stretch: cellType.stretch
                    };
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        document.documentElement.style.setProperty('--el-transition-duration', "0s");
                        this.value = value;
                        this.activeName = value === null || value === void 0 ? void 0 : value.toString();
                        self.setElTransitionDurationProperty(true);
                    },
                    ItemClick: function (tab) {
                        var _this = this;
                        self.setElTransitionDurationProperty(false);
                        setTimeout(function () {
                            var _a, _b;
                            var index = Number(tab.index);
                            if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                                var initValue = {};
                                initValue[cellType.ClickCommand.ParamProperties["itemIndex"]] = index + 1;
                                initValue[cellType.ClickCommand.ParamProperties["itemValue"]] = _this.tabs[index].Value;
                                initValue[cellType.ClickCommand.ParamProperties["itemText"]] = tab.props.label;
                                self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                            }
                            self.commitValue();
                        }, transitionDuration * 1000);
                    },
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                    if (dataSource) {
                        dataSource.every(function (i) { var _a; return i.ValueStr = (_a = i.Value) === null || _a === void 0 ? void 0 : _a.toString(); });
                    }
                    _this.vue.tabs = dataSource !== null && dataSource !== void 0 ? dataSource : [];
                });
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        TabHeaderCellType.prototype.HideItems = function (value) {
            var _a;
            var itemArray = (_a = value === null || value === void 0 ? void 0 : value.split(',')) === null || _a === void 0 ? void 0 : _a.map(function (item) { return item.toString(); });
            if (!(itemArray === null || itemArray === void 0 ? void 0 : itemArray.length)) {
                return;
            }
            this.vue.tabs = this.vue.tabs.filter(function (tab) { var _a; return !itemArray.includes((_a = tab.Value) === null || _a === void 0 ? void 0 : _a.toString()); });
        };
        return TabHeaderCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.TabHeaderCellType = TabHeaderCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TabHeader, ElementUI", ElementCellTypes.TabHeaderCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TagCellType = /** @class */ (function (_super) {
        __extends(TagCellType, _super);
        function TagCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TagCellType.prototype.getColor = function (color) {
            color = Forguncy.ConvertToCssColor(color);
            switch (this.cellType.effect) {
                case "dark":
                    return "#fff";
                case "light":
                    return color;
                case "plain":
                    return color;
                default:
            }
        };
        ;
        TagCellType.prototype.onPageLoaded = function (info) {
            var cellType = this.cellType;
            var self = this;
            var colorList = cellType.ColorList;
            var marginBottom = "";
            var WordWrap = this.CellElement.StyleInfo.WordWrap;
            if (WordWrap) {
                marginBottom = ",marginBottom:itemSpace+'px'";
            }
            this.fontSelector = [".el-tag__content", ".el-button-new-tag"];
            var html = '';
            for (var i = 0; i < colorList.length; i++) {
                var color = this.getColor(colorList[i % colorList.length].color);
                var isDark = this.cellType.effect === "dark";
                html += "#".concat(this.uId, " .fgc-tag-container-tag-").concat(i, "  svg {\n                             color: ").concat(color, ";\n                         }\n                         #").concat(this.uId, " .fgc-tag-container-tag-").concat(i, " svg:hover{\n                             color: #fff;\n                         }\n                         #").concat(this.uId, " .fgc-tag-container-tag-").concat(i, " .el-icon:hover{\n                             background-color: ").concat(!isDark ? color : Forguncy.ColorHelper.UpdateTint(color, 30, 128), ";\n                         }\n");
            }
            this.getStyleContainerElement("tags").innerHTML = html;
            var template = "\n<el-scrollbar class=\"fgc-tag-scrollbar ".concat(WordWrap ? 'fgc-tag-word-wrap' : '', "\">\n    <div class=\"fgc-tag-container\">\n            <el-tag\n                ref=\"tags\"\n                v-for=\"item in items\"\n                :key=\"item.key\"\n                :size=\"size\"\n                :effect=\"effect\"\n                :hit=\"hit\"\n                :closable=\"!disabled&&!readonly\"\n                :disableTransitions=\"disableTransitions\"\n                :class=\"item.class\"\n                @click=\"onClick\"\n                @close=\"onClose\"\n                :color=\"item.background\"\n                :style=\"{marginRight:item.itemSpace+'px'").concat(marginBottom, ",cursor:item.cursor, borderColor:item.border, color: item.color}\"\n                >\n                {{ item.label }}\n             </el-tag>\n            <el-input\n                  :size=\"addButtonSize\"\n                  class=\"el-input-new-tag\"\n                  v-if=\"inputVisible\"\n                  v-model=\"inputValue\"\n                  ref=\"saveTagInput\"\n                  @keyup.enter.native=\"handleInputConfirm\"\n                  @blur=\"handleInputConfirm\"\n                  :style=\"{display:!disabled&&!readonly&&allowAdd?'':'none', flexShrink:0,width:addButtonWidth+'px'").concat(marginBottom, "}\"\n                >\n            </el-input>\n            <el-button clickable=\"true\" :size=\"addButtonSize\" :style=\"{display:!disabled&&!readonly&&allowAdd?'':'none',flexShrink:0, width:addButtonWidth+'px'").concat(marginBottom, "}\" v-else class=\"el-button-new-tag\" @click=\"showInput\">{{addButtonText}}</el-button>\n    </div>\n</el-scrollbar>\n");
            var option = {
                template: template,
                data: function () {
                    var _a;
                    return {
                        items: [],
                        size: cellType.size === "mini" ? "small" : cellType.size,
                        effect: cellType.effect,
                        hit: !!cellType.hit,
                        disabled: false,
                        readonly: false,
                        itemSpace: cellType.itemSpace,
                        allowAdd: cellType.allowAdd,
                        disableTransitions: !!cellType.disableTransitions,
                        inputVisible: false,
                        addButtonWidth: cellType.addButtonSettings.width,
                        addButtonText: (_a = cellType.addButtonSettings.text) !== null && _a !== void 0 ? _a : "",
                        addButtonSize: this.getAddButtonSize(cellType.size),
                        inputValue: ''
                    };
                },
                methods: {
                    getValue: function () {
                        return this.items ? this.items.map(function (i) { return i.label; }).join(cellType.separator) : null;
                    },
                    setValue: function (value) {
                        var _this = this;
                        var hasAddButton = !this.readonly && !this.disabled && cellType.allowAdd;
                        if (value || value === 0) {
                            var strItems = (value + "").split(cellType.separator).filter(function (i) { return i !== ""; });
                            if (cellType.distinct) {
                                strItems = this.distinct(strItems);
                            }
                            this.items = strItems.map(function (value, index, array) {
                                var _a, _b;
                                return ({
                                    key: cellType.distinct ? value : index,
                                    label: value,
                                    class: "fgc-tag-container-tag-".concat(index % colorList.length),
                                    background: _this.getBackground(colorList[index % colorList.length].color),
                                    color: _this.getColor(colorList[index % colorList.length].color),
                                    border: _this.getBorder(colorList[index % colorList.length].color),
                                    itemSpace: index !== array.length - 1 ? cellType.itemSpace : (hasAddButton ? cellType.addButtonSettings.space : 0),
                                    cursor: ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) ? "pointer" : ""
                                });
                            });
                        }
                        else {
                            this.items = [];
                        }
                    },
                    onClick: function (event) {
                        var _a, _b;
                        if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var index = this.getEventIndex(event);
                            if (index >= 0) {
                                var initValue = {};
                                initValue[cellType.ClickCommand.ParamProperties["itemName"]] = this.items[index].label;
                                self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                            }
                        }
                    },
                    onClose: function (event) {
                        var index = this.getEventIndex(event);
                        if (index >= 0) {
                            this.items.splice(index, 1);
                            self.commitValue();
                        }
                    },
                    getAddButtonSize: function (size) {
                        switch (size) {
                            case "large":
                                return "default";
                            default:
                                return "small";
                        }
                    },
                    getEventIndex: function (event) {
                        var clickItem = $(event.target, self.getContainer()).parents(".el-tag")[0];
                        var tags = $(".el-tag", self.getContainer());
                        for (var i = 0; i < tags.length; i++) {
                            var item = tags[i];
                            if (item === clickItem) {
                                return i;
                            }
                        }
                    },
                    distinct: function (arr) {
                        var result = [];
                        var obj = {};
                        for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
                            var i = arr_1[_i];
                            if (obj[i]) {
                                continue;
                            }
                            obj[i] = true;
                            result.push(i);
                        }
                        return result;
                    },
                    getBorder: function (color) {
                        color = Forguncy.ConvertToCssColor(color);
                        if (this.hit) {
                            return color;
                        }
                        switch (this.effect) {
                            case "dark":
                                return color;
                            case "light":
                                return Forguncy.ColorHelper.UpdateTint(color, 0.8, 255);
                            case "plain":
                                return Forguncy.ColorHelper.UpdateTint(color, 0.6, 255);
                            default:
                        }
                    },
                    getColor: function (color) {
                        color = Forguncy.ConvertToCssColor(color);
                        switch (this.effect) {
                            case "dark":
                                return "#fff";
                            case "light":
                                return color;
                            case "plain":
                                return color;
                            default:
                        }
                    },
                    getBackground: function (color) {
                        color = Forguncy.ConvertToCssColor(color);
                        switch (this.effect) {
                            case "dark":
                                return color;
                            case "light":
                                return Forguncy.ColorHelper.UpdateTint(color, 0.9, 255);
                            case "plain":
                                return "#fff";
                            default:
                        }
                    },
                    showInput: function () {
                        var _this = this;
                        this.inputVisible = true;
                        this.$nextTick(function (_) {
                            _this.$refs.saveTagInput.$refs.input.focus();
                        });
                    },
                    handleInputConfirm: function () {
                        var inputValue = this.inputValue;
                        if (inputValue) {
                            var currentValue = this.getValue();
                            this.setValue(currentValue ? currentValue + cellType.separator + inputValue : inputValue);
                            self.commitValue();
                        }
                        this.inputVisible = false;
                        this.inputValue = '';
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        TagCellType.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.refreshClickable();
        };
        TagCellType.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.refreshClickable();
        };
        TagCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.refreshClickable();
        };
        TagCellType.prototype.refreshClickable = function () {
            var _a, _b;
            (_a = this.getContainer()) === null || _a === void 0 ? void 0 : _a.attr("clickable", this.clickable() ? true : "");
            (_b = this.getContainer()) === null || _b === void 0 ? void 0 : _b.css("cursor", this.clickable() ? "default" : "");
        };
        TagCellType.prototype.clickable = function () {
            var _a;
            var cellType = this.cellType;
            return (!this.isReadOnly() && !this.isDisabled()) || (((_a = cellType === null || cellType === void 0 ? void 0 : cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) && cellType.ClickCommand.Commands.length > 0);
        };
        return TagCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.TagCellType = TagCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.Tag, ElementUI", ElementCellTypes.TagCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TimePickerCellType = /** @class */ (function (_super) {
        __extends(TimePickerCellType, _super);
        function TimePickerCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TimePickerCellType.prototype.resolveTimeNumber = function (value) {
            return value < 10 ? "0".concat(value) : value;
        };
        TimePickerCellType.prototype.parseTime = function (value, needSeconds) {
            if (value === void 0) { value = 0; }
            if (needSeconds === void 0) { needSeconds = true; }
            var date = Forguncy.ConvertOADateToDate(value);
            var hours = date.getHours();
            var minutes = date.getMinutes();
            var seconds = date.getSeconds();
            var time = "".concat(this.resolveTimeNumber(hours), ":").concat(this.resolveTimeNumber(minutes));
            if (needSeconds) {
                time += ":" + this.resolveTimeNumber(seconds);
            }
            return { hours: hours, minutes: minutes, seconds: seconds, time: time };
        };
        TimePickerCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var CssClassName = this.CellElement.CssClassName;
            var popperClass = CssClassName ? "".concat(CssClassName, "-popper") : "";
            var rangeTemplate = "\n:is-range=\"true\"\n:range-separator=\"rangeSeparator\"\n:start-placeholder=\"startPlaceholder\"\n:end-placeholder=\"endPlaceholder\"\n";
            var pickerTemplate = "\n<el-time-picker v-model=\"input\"\n:clearable=\"clearable\"\n:disabled=\"disabled\"\n:editable=\"editable\"\n:placeholder=\"placeholder\"\n:prefix-icon=\"prefixIcon\"\n:format=\"format\"\n:disabled-hours=\"disabledHours\"\n:disabled-minutes=\"disabledMinutes\"\n:disabled-seconds=\"disabledSeconds\"\n:readonly=\"readOnly\"\npopper-class=\"".concat(popperClass, "\"\n").concat(cellType.isRange ? rangeTemplate : "", "\n@change=\"handleChange\">\n</el-time-picker>");
            var selectTemplate = "\n<el-time-select v-model=\"input\"\n:clearable=\"clearable\"\n:disabled=\"disabled\"\n:editable=\"editable\"\n:step=\"step\"\n:start=\"start\"\n:end=\"end\"\n:placeholder=\"placeholder\"\n:prefix-icon=\"prefixIcon\"\n:readonly=\"readOnly\"\npopper-class=\"".concat(popperClass, "\"\n@change=\"handleChange\">\n</el-time-select>");
            var isSelect = cellType.mode === "select";
            var useTemplate = isSelect ? selectTemplate : pickerTemplate;
            this.addCustomClass(isSelect ? "el-time-select-custom" : "el-time-picker-custom");
            var _a = this.parseTime(cellType.StartTime), startTime = _a.time, startHour = _a.hours, startMinutes = _a.minutes, startSeconds = _a.seconds;
            var _b = this.parseTime(cellType.EndTime), endTime = _b.time, endHour = _b.hours, endMinutes = _b.minutes, endSeconds = _b.seconds;
            var option = {
                el: "#" + this.uId,
                template: useTemplate,
                data: function () {
                    return {
                        input: null,
                        clearable: this.boolConvertor(cellType.clearable),
                        disabled: cellType.IsDisabled,
                        editable: this.boolConvertor(cellType.editable),
                        readOnly: undefined,
                        placeholder: cellType.placeholder,
                        prefixIcon: "",
                        rangeSeparator: cellType.rangeSeparator,
                        startPlaceholder: cellType.startPlaceholder,
                        endPlaceholder: cellType.endPlaceholder,
                        step: self.parseTime(cellType.step, false).time,
                        format: "HH:mm:ss",
                        start: startTime,
                        end: endTime
                    };
                },
                methods: {
                    handleChange: function () {
                        self.commitValue();
                        self.validate();
                    },
                    makeRange: function (start, end) {
                        var result = [];
                        for (var i = start; i <= end; i++) {
                            result.push(i);
                        }
                        return result;
                    },
                    disabledHours: function () {
                        return this.makeRange(0, startHour - 1).concat(this.makeRange(endHour + 1, 23));
                    },
                    disabledMinutes: function (hour) {
                        if (hour === startHour) {
                            return this.makeRange(0, startMinutes - 1);
                        }
                        if (hour === endHour) {
                            return this.makeRange(endMinutes + 1, 59);
                        }
                    },
                    disabledSeconds: function (hour, minute) {
                        if (hour === startHour && minute === startMinutes) {
                            return this.makeRange(0, startSeconds - 1);
                        }
                        if (hour === endHour && minute === endMinutes) {
                            return this.makeRange(endSeconds + 1, 59);
                        }
                    },
                    convertDateToOADate: function (value) {
                        var date = Forguncy.ConvertOADateToDate(0);
                        date.setHours(value.getHours());
                        date.setMinutes(value.getMinutes());
                        date.setSeconds(value.getSeconds());
                        return Forguncy.ConvertDateToOADate(date);
                    },
                    getValue: function () {
                        if (!this.input) {
                            return null;
                        }
                        if (cellType.isRange) {
                            return this.input.map(this.convertDateToOADate).join(",");
                        }
                        var inputIsDate = this.input instanceof Date;
                        return this.convertDateToOADate(inputIsDate ? this.input : new Date("1970/1/1 ".concat(this.input)));
                    },
                    setValue: function (value) {
                        var convertValueToInput = function () {
                            if (!value) {
                                return null;
                            }
                            if (cellType.mode === "select") {
                                return self.parseTime(value, false).time;
                            }
                            if (typeof value === "number") {
                                return Forguncy.ConvertOADateToDate(value);
                            }
                            if (typeof value === "string") {
                                var convertTimeToDateOptions_1 = { year: 1970, month: 0, day: 1 };
                                if (cellType.isRange) {
                                    return value.split(",").map(function (item) { return ElementCellTypes.DateUtil.ConverTimeToDate(item, convertTimeToDateOptions_1); });
                                }
                                return ElementCellTypes.DateUtil.ConverTimeToDate(value, convertTimeToDateOptions_1);
                            }
                            return value;
                        };
                        this.input = convertValueToInput();
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readOnly = value;
                    },
                    boolConvertor: function (value) {
                        return value ? true : false;
                    },
                },
                mounted: function () {
                    self.fontDom = $("input", "#".concat(self.uId));
                    self.setFontToDom();
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
            _super.prototype.getIconComponent.call(this, cellType.prefixIcon, function (icon) { return _this.vue.prefixIcon = icon; });
        };
        TimePickerCellType.prototype.GetSelectedRange = function () {
            var value = this.vue.input;
            var _a = value instanceof Array ? value : [], startDaTe = _a[0], endDate = _a[1];
            return {
                StartValue: Forguncy.ConvertDateToOADate(startDaTe) - Math.floor(Forguncy.ConvertDateToOADate(startDaTe)),
                EndValue: Forguncy.ConvertDateToOADate(endDate) - Math.floor(Forguncy.ConvertDateToOADate(endDate)),
            };
        };
        return TimePickerCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.TimePickerCellType = TimePickerCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TimePickerCellType, ElementUI", ElementCellTypes.TimePickerCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TimelinePlacement;
    (function (TimelinePlacement) {
        TimelinePlacement[TimelinePlacement["top"] = 0] = "top";
        TimelinePlacement[TimelinePlacement["bottom"] = 1] = "bottom";
    })(TimelinePlacement || (TimelinePlacement = {}));
    function formatDate(date, fmt) {
        var o = {
            "M+": date.getMonth() + 1,
            "d+": date.getDate(),
            "H+": date.getHours(),
            "m+": date.getMinutes(),
            "s+": date.getSeconds(),
            "q+": Math.floor((date.getMonth() + 3) / 3),
            "S": date.getMilliseconds()
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        }
        ;
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return fmt;
    }
    var TimelineCellType = /** @class */ (function (_super) {
        __extends(TimelineCellType, _super);
        function TimelineCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TimelineCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        TimelineCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var self = this;
            var option = {
                el: "#" + this.uId,
                template: "<el-scrollbar>\n                                <el-timeline>\n                                    <el-timeline-item\n                                         v-for=\"(activity, index) in activities\"\n                                         :key=\"index\"\n                                         :timestamp=\"activity.timestamp\"\n                                         :icon=\"activity.iconComponent\"\n                                         :color=\"activity.color\"\n                                         :size=\"nodeSize\"\n                                         :hide-timestamp=\"hideTimestamp\"\n                                         :placement=\"placement\"\n                                         >\n                                      {{activity.content}}\n                                    </el-timeline-item>\n                                 </el-timeline>\n                            </el-scrollbar>\n                          ",
                data: function () {
                    return {
                        activities: [],
                        hideTimestamp: cellType.hideTimestamp,
                        placement: TimelinePlacement[cellType.placement],
                        nodeSize: cellType.NodeSize
                    };
                },
                methods: {
                    getValue: function () {
                        return this.active;
                    },
                    setValue: function (value) {
                        this.active = value;
                    },
                    sort: function (type, a, b) {
                        var value1 = a.timestamp;
                        if (typeof (a.timestamp) === "string") {
                            value1 = new Date(a.timestamp);
                        }
                        var value2 = b.timestamp;
                        if (typeof (b.timestamp) === "string") {
                            value2 = new Date(b.timestamp);
                        }
                        return type === "ascTimestamp" ? value1 - value2 : value2 - value1;
                    },
                    formatOption: function (option) {
                        var timestamp = option.timestamp, color = option.color;
                        var isNumber = typeof (timestamp) === "number" || !isNaN(Number(timestamp));
                        var getDate = function (isOADate) {
                            var _a;
                            if (isOADate === void 0) { isOADate = true; }
                            if (isOADate) {
                                var date_1 = Forguncy.ConvertOADateToDate(timestamp);
                                var isInvalidDate = isNaN(date_1.getTime());
                                return isInvalidDate ? getDate(false) : date_1;
                            }
                            var dateString = isNumber ? Number(timestamp) : (_a = timestamp) === null || _a === void 0 ? void 0 : _a.replace(/-/g, "/");
                            return new Date(dateString);
                        };
                        var date = getDate();
                        var newTimestamp = self.isValidDate(date)
                            ? formatDate(date, cellType.format || "yyyy/MM/dd")
                            : timestamp;
                        return __assign(__assign({}, option), { timestamp: newTimestamp, color: Forguncy.ConvertToCssColor(color) });
                    },
                    setOptions: function (options) {
                        var activities = options.map(this.formatOption);
                        this.activities = cellType.sort === "default" ? activities : activities.sort(this.sort.bind(this, cellType.sort));
                        self.recalcIcon();
                    },
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
            else {
                this.vue.setOptions(cellType.options);
            }
            self.recalcIcon();
        };
        TimelineCellType.prototype.recalcIcon = function () {
            var _loop_4 = function (i) {
                var option = this_4.vue.activities[i];
                var icon = option === null || option === void 0 ? void 0 : option.icon;
                this_4.getIconComponent(icon, function (icon) { return option.iconComponent = icon; });
            };
            var this_4 = this;
            for (var i = 0; i < this.vue.activities.length; i++) {
                _loop_4(i);
            }
        };
        TimelineCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        TimelineCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        TimelineCellType.prototype.SetDataSource = function (dataSource, contentProperty, timestempProperty) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var objSource = dataSource.map(function (i) { return ({
                "content": i[contentProperty],
                "timestamp": i[timestempProperty],
            }); });
            this.setDataSource(objSource);
        };
        return TimelineCellType;
    }(ElementCellTypes.ElementCellTypeBase));
    ElementCellTypes.TimelineCellType = TimelineCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TimelineCellType, ElementUI", ElementCellTypes.TimelineCellType);
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var TransferTargetOrder;
    (function (TransferTargetOrder) {
        TransferTargetOrder[TransferTargetOrder["original"] = 0] = "original";
        TransferTargetOrder[TransferTargetOrder["push"] = 1] = "push";
        TransferTargetOrder[TransferTargetOrder["unshift"] = 2] = "unshift";
    })(TransferTargetOrder || (TransferTargetOrder = {}));
    var TransferCellType = /** @class */ (function (_super) {
        __extends(TransferCellType, _super);
        function TransferCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TransferCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        TransferCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var containerId = "".concat(this.uId, "-el-transfer");
            var self = this;
            var formatData = function (data) {
                if (data === void 0) { data = []; }
                return data.map(function (_a) {
                    var key = _a.key, label = _a.label, _b = _a.disabled, disabled = _b === void 0 ? false : _b;
                    return ({
                        label: label === null || label === void 0 ? void 0 : label.toString(),
                        key: key === null || key === void 0 ? void 0 : key.toString(),
                        disabled: !!disabled
                    });
                });
            };
            var option = {
                template: "<div id=\"".concat(containerId, "\" style=\"width: 100%;height: 100%;overflow: auto\">\n                                <el-transfer\n                                     v-model=\"value\"\n                                     :titles=\"titles\"\n                                     :data=\"data\"\n                                     :filterable=\"filterable\"\n                                     :filter-placeholder=\"filterPlaceholder\"\n                                     :target-order=\"targetOrder\"\n                                     @change=\"handleChange\"\n                                     :render-content=\"renderContent\"\n                                 />\n                            </div>\n                          "),
                data: function () {
                    return {
                        value: [],
                        titles: [cellType.leftTitle, cellType.rightTitle],
                        filterable: !!cellType.filterable,
                        filterPlaceholder: cellType.filterPlaceholder,
                        data: cellType.useBinding ? [] : formatData(cellType.options),
                        targetOrder: TransferTargetOrder[cellType.targetOrder]
                    };
                },
                methods: {
                    getValue: function () {
                        if (this.value instanceof Array) {
                            return this.value.join(",");
                        }
                        return this.value;
                    },
                    setValue: function (value) {
                        var _this = this;
                        var list = [];
                        if (value instanceof Array) {
                            list = value;
                        }
                        else {
                            list = typeof value === "string" ? value.split(",") : [value];
                        }
                        this.value = list.filter(function (item) { return _this.data.find(function (_a) {
                            var key = _a.key;
                            return key === item;
                        }); });
                    },
                    setOptions: function (options) {
                        this.data = formatData(options);
                    },
                    handleChange: function () {
                        var _this = this;
                        var _a;
                        this.value = (_a = this.value) === null || _a === void 0 ? void 0 : _a.filter(function (val) { return _this.data.find(function (_a) {
                            var key = _a.key;
                            return key === val;
                        }); });
                        self.commitValue();
                    },
                    renderContent: function (h, option) {
                        return self.customRender(h, option);
                    }
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        TransferCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.CellElement.CellType;
            if (cellType.useBinding) {
                ElementCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        TransferCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        TransferCellType.prototype.customRender = function (h, option) {
            return h("span", option.label);
        };
        return TransferCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.TransferCellType = TransferCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.TransferCellType, ElementUI", ElementCellTypes.TransferCellType);
var ElementCellTypes;
(function (ElementCellTypes) {
    var TreeHelper = /** @class */ (function () {
        function TreeHelper() {
        }
        TreeHelper.build = function (nodes) {
            var _this = this;
            if (!nodes) {
                return undefined;
            }
            var allDataNodes = nodes.map(function (item) { return (__assign({}, item)); });
            for (var _i = 0, allDataNodes_1 = allDataNodes; _i < allDataNodes_1.length; _i++) {
                var node = allDataNodes_1[_i];
                node.uId = this.getUid(node.value, node.parentValue);
            }
            var uidNodesCache = {};
            var idNodesCache = {};
            var parentIdNodesCache = {};
            for (var _a = 0, allDataNodes_2 = allDataNodes; _a < allDataNodes_2.length; _a++) {
                var node = allDataNodes_2[_a];
                uidNodesCache[node.uId] = node;
            }
            for (var _b = 0, allDataNodes_3 = allDataNodes; _b < allDataNodes_3.length; _b++) {
                var node = allDataNodes_3[_b];
                if (!idNodesCache[node.value]) {
                    idNodesCache[node.value] = [];
                }
                idNodesCache[node.value].push(node);
            }
            for (var _c = 0, allDataNodes_4 = allDataNodes; _c < allDataNodes_4.length; _c++) {
                var node = allDataNodes_4[_c];
                if (!parentIdNodesCache[node.parentValue]) {
                    parentIdNodesCache[node.parentValue] = [];
                }
                parentIdNodesCache[node.parentValue].push(node);
            }
            this.buildChildren(allDataNodes, parentIdNodesCache);
            var roots = allDataNodes.filter(function (i) { return _this.isRootNode(i, idNodesCache); });
            var exsitId = {};
            var uniqueRoots = roots.filter(function (i) {
                if (exsitId[i.value]) {
                    return false;
                }
                exsitId[i.value] = true;
                return true;
            });
            return uniqueRoots;
        };
        TreeHelper.getUid = function (id, pid) {
            return (id !== null && id !== void 0 ? id : "") + "_%_" + (pid !== null && pid !== void 0 ? pid : "");
        };
        TreeHelper.buildChildren = function (nodes, parentIdDataNodesCache) {
            for (var _i = 0, nodes_3 = nodes; _i < nodes_3.length; _i++) {
                var node = nodes_3[_i];
                var children = parentIdDataNodesCache[node.value];
                if (children) {
                    node.children = children;
                }
                else {
                    node.children = null;
                }
            }
        };
        TreeHelper.isRootNode = function (node, idNodesCache) {
            if (!node.parentValue) {
                return true;
            }
            var nodes = idNodesCache[node.parentValue];
            if (!nodes) {
                return true;
            }
            return false;
        };
        TreeHelper.flat = function (nodes) {
            var result = [];
            if (nodes && nodes.length) {
                for (var _i = 0, nodes_4 = nodes; _i < nodes_4.length; _i++) {
                    var n = nodes_4[_i];
                    result.push(n);
                    var subResult = this.flat(n.children);
                    subResult.every(function (i) { return result.push(i); });
                }
            }
            return result;
        };
        return TreeHelper;
    }());
    ElementCellTypes.TreeHelper = TreeHelper;
})(ElementCellTypes || (ElementCellTypes = {}));
/// <reference path = "Base.ts" />
var ElementCellTypes;
(function (ElementCellTypes) {
    var UploadListType;
    (function (UploadListType) {
        UploadListType[UploadListType["upload"] = 0] = "upload";
        UploadListType[UploadListType["pictureList"] = 1] = "pictureList";
        UploadListType[UploadListType["pictureCard"] = 2] = "pictureCard";
    })(UploadListType || (UploadListType = {}));
    var UploadCellType = /** @class */ (function (_super) {
        __extends(UploadCellType, _super);
        function UploadCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        UploadCellType.prototype.onPageLoaded = function (info) {
            var self = this;
            var cellType = this.cellType;
            var bindingStr = "action=\"#\"\n:multiple=\"multiple\"\n:limit=\"limit\"\n:on-exceed=\"handleExceed\"\n:on-success=\"handleSuccess\"\n:on-remove=\"handleRemove\"\n:disabled=\"disabled || readOnly\"\n:on-preview=\"handlePreview\"\n:before-upload=\"handleBeforeUpload\"\n:http-request=\"httpRequest\"\n:accept=\"accept\"\n:file-list=\"fileList\" ";
            this.addCustomClass("el-upload-custom");
            var getTemplate = function () {
                if (cellType.listType === UploadListType.upload) {
                    return "<el-upload class=\"upload-demo\" ".concat(bindingStr, " list-type=\"text\">\n                                <el-button :disabled=\"disabled\" size=\"default\" type=\"primary\" v-if=\"!readOnly\">{{buttonText}}</el-button>\n                                <template #tip>\n                                    <div class=\"el-upload__tip\" :style=\"{ display: tipDisplay }\" v-if=\"!readOnly\">{{tipText}}</div>\n                                </template>\n                            </el-upload>");
                }
                if (cellType.listType === UploadListType.pictureCard) {
                    return "<el-upload ".concat(bindingStr, " list-type=\"picture-card\">\n                                <el-icon>").concat(ElementCellTypes.ElementIconMap.get("plus"), "</el-icon>\n                            </el-upload>");
                }
                if (cellType.listType === UploadListType.pictureList) {
                    return "<el-upload ".concat(bindingStr, " list-type=\"picture\" class=\"el-upload-picture-custom\">\n                                <el-button :disabled=\"disabled\" type=\"primary\" v-if=\"!readOnly\">{{buttonText}}</el-button>\n\n                                <template #tip v-if=\"!readOnly\">\n                                    <div class=\"el-upload__tip\" :style=\"{ display: tipDisplay }\" >{{tipText}}</div>\n                                </template>\n                            </el-upload>");
                }
            };
            var CssClassName = this.CellElement.CssClassName;
            var dialogCustomClass = CssClassName ? "".concat(CssClassName, "-upload-dialog") : "";
            var template = "<el-scrollbar>".concat(getTemplate(), "\n                                  <el-dialog append-to-body v-model=\"dialogVisible\" custom-class=\"fgc-upload-dialog ").concat(dialogCustomClass, "\">\n                                      <img style=\"max-width:100%;object-fit:contain;\" :src=\"dialogImageUrl\" alt=\"\" />\n                                  </el-dialog>\n                              </el-scrollbar>");
            var option = {
                el: "#" + this.uId,
                template: template,
                data: function () {
                    return {
                        multiple: cellType.multiple,
                        limit: cellType.limit,
                        accept: cellType.accept,
                        sizeLimit: cellType.sizeLimit,
                        buttonText: cellType.buttonText,
                        tipText: cellType.tipText,
                        tipDisplay: cellType.tipText ? "" : "none",
                        disabled: undefined,
                        fileList: [],
                        dialogImageUrl: '',
                        dialogVisible: false,
                        readOnly: null,
                        successSet: new Set()
                    };
                },
                methods: {
                    getValue: function () {
                        var fileList = this.fileList;
                        if (this.updatingFileList) {
                            fileList = this.updatingFileList;
                        }
                        var text = fileList.map(function (i) { return i.fgc_fileName; }).join("|");
                        return text ? text + "|" : null;
                    },
                    setValue: function (value) {
                        if (value === this.getValue()) {
                            return;
                        }
                        this.updatingFileList = null;
                        if (value) {
                            var values = value.split("|");
                            this.fileList = values.filter(function (i) { return i; }).map(function (i) {
                                if (i && i.length > 37 && i.charAt(36) === "_") {
                                    var fileName = i.substring(37);
                                    return {
                                        isBoundData: true,
                                        name: fileName,
                                        fgc_fileName: i,
                                        url: UploadCellType.getFileUrl(i)
                                    };
                                }
                            });
                        }
                        else {
                            this.fileList = [];
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                        self.addCustomClass("disable");
                    },
                    enable: function () {
                        this.disabled = false;
                        self.getContainer().removeClass("disable");
                    },
                    setReadOnly: function (readOnly) {
                        if (cellType.listType === UploadListType.pictureCard) {
                            $(".el-upload--picture-card", self.getContainer()).css("display", readOnly ? "none" : "flex");
                        }
                        this.readOnly = readOnly;
                    },
                    handleSuccess: function (response, file, fileList) {
                        this.successSet.add(file.uid);
                        file.fgc_fileName = response;
                        file.url = UploadCellType.getFileUrl(response);
                        this.updatingFileList = fileList;
                        self.commitValue();
                    },
                    handleExceed: function (files, fileList) {
                        var error = cellType.OverFileCountLimitError;
                        error = error.replace("${limit}", this.limit);
                        error = error.replace("${length}", files.length);
                        error = error.replace("${total}", files.length + fileList.length);
                        this.$message.error(error);
                    },
                    httpRequest: function (data) {
                        var root = Forguncy.Helper.SpecialPath.getBaseUrl();
                        var uploadPath = root + "FileDownloadUpload/Upload";
                        var formData = new FormData();
                        formData.append("file", data.file);
                        formData.append("uploadLimitId", self.CellElement.ServerPropertiesId.UploadLimit);
                        $.ajax({
                            url: uploadPath,
                            type: 'POST',
                            success: function (responseData) {
                                data.onSuccess(responseData);
                            },
                            error: function () {
                                data.onError();
                            },
                            data: formData,
                            cache: false,
                            contentType: false,
                            processData: false,
                            headers: {
                                "Accept": "application/json"
                            }
                        });
                    },
                    handlePreview: function (file) {
                        if (!file.isBoundData && !this.successSet.has(file.uid)) {
                            return;
                        }
                        if (UploadCellType.isImage(file.name)) {
                            this.dialogImageUrl = file.url;
                            this.dialogVisible = true;
                        }
                        else {
                            Forguncy.Common.download(file.url);
                        }
                    },
                    handleBeforeUpload: function (file) {
                        if (cellType.accept) {
                            var exts = cellType.accept.split(",").filter(function (i) { return i; }).map(function (i) { return i.trim(); });
                            if (!exts.some(function (i) { return file.name.endsWith(i); })) {
                                this.$message.error(cellType.FileFormatError);
                                return false;
                            }
                        }
                        if (cellType.sizeLimit) {
                            if (file.size / 1024 / 1024 > cellType.sizeLimit) {
                                this.$message.error(cellType.OverFileSizeLimitError);
                                return false;
                            }
                        }
                        return true;
                    },
                    handleRemove: function (file, fileList) {
                        this.updatingFileList = fileList;
                        self.commitValue();
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        UploadCellType.getFileUrl = function (fileName) {
            return Forguncy.Helper.SpecialPath.getBaseUrl() + Forguncy.ModuleLoader.getCdnUrl("FileDownloadUpload/Download?file=" + encodeURIComponent(fileName));
        };
        UploadCellType.isImage = function (fileName) {
            if (fileName) {
                var pointIndex = fileName.lastIndexOf(".");
                if (pointIndex) {
                    var extension_1 = fileName.toLowerCase().substring(pointIndex + 1, fileName.length);
                    return ["jpg", "jpeg", "png", "gif", "eps", "svg", "bmp", "tif", "tiff"].some(function (i) { return i === extension_1; });
                }
            }
            return false;
        };
        return UploadCellType;
    }(ElementCellTypes.InputCellTypeBase));
    ElementCellTypes.UploadCellType = UploadCellType;
})(ElementCellTypes || (ElementCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("ElementUI.UploadCellType, ElementUI", ElementCellTypes.UploadCellType);
var ElementCommands;
(function (ElementCommands) {
    var ElementCommandBase = /** @class */ (function (_super) {
        __extends(ElementCommandBase, _super);
        function ElementCommandBase() {
            var _a;
            var _this = this;
            (_a = window["elementUITheme"]) === null || _a === void 0 ? void 0 : _a.UpdateCssAndAppend();
            _this = _super.call(this) || this;
            return _this;
        }
        return ElementCommandBase;
    }(Forguncy.Plugin.CommandBase));
    ElementCommands.ElementCommandBase = ElementCommandBase;
})(ElementCommands || (ElementCommands = {}));
/// <reference path = "ELCommandBase.ts" />
var ElementCommands;
(function (ElementCommands) {
    var ShowMessage = /** @class */ (function (_super) {
        __extends(ShowMessage, _super);
        function ShowMessage() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ShowMessage.prototype.execute = function () {
            var _a, _b, _c;
            var _d = this.CommandParam, Center = _d.Center, Duration = _d.Duration, Message = _d.Message, Offset = _d.Offset, ShowClose = _d.ShowClose, Type = _d.Type;
            var duration = (_a = this.evaluateFormula(Duration)) !== null && _a !== void 0 ? _a : 0;
            var offset = (_b = this.evaluateFormula(Offset)) !== null && _b !== void 0 ? _b : 20;
            var type = this.evaluateFormula(Type);
            var message = (_c = this.evaluateFormula(Message)) !== null && _c !== void 0 ? _c : "";
            var center = !!Center;
            var showClose = !!ShowClose;
            window.ElementPlus.ElMessage({
                duration: duration,
                message: message,
                type: type,
                center: center,
                showClose: showClose,
                offset: Number(offset),
            });
        };
        return ShowMessage;
    }(ElementCommands.ElementCommandBase));
    ElementCommands.ShowMessage = ShowMessage;
})(ElementCommands || (ElementCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ElementUI.Commands.ShowMessage, ElementUI", ElementCommands.ShowMessage);
/// <reference path = "ELCommandBase.ts" />
var ElementCommands;
(function (ElementCommands) {
    var ShowMessBoxInputType;
    (function (ShowMessBoxInputType) {
        ShowMessBoxInputType[ShowMessBoxInputType["text"] = 0] = "text";
        ShowMessBoxInputType[ShowMessBoxInputType["textarea"] = 1] = "textarea";
        ShowMessBoxInputType[ShowMessBoxInputType["password"] = 2] = "password";
    })(ShowMessBoxInputType || (ShowMessBoxInputType = {}));
    var ShowMessageBox = /** @class */ (function (_super) {
        __extends(ShowMessageBox, _super);
        function ShowMessageBox() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ShowMessageBox.prototype.execute = function () {
            var _this = this;
            var _a = this.CommandParam, Title = _a.Title, Message = _a.Message, ShowClose = _a.ShowClose, Type = _a.Type, ShowConfirmButton = _a.ShowConfirmButton, ConfirmButtonText = _a.ConfirmButtonText, ShowCancelButton = _a.ShowCancelButton, CancelButtonText = _a.CancelButtonText, DialogResult = _a.DialogResult, _b = _a.AdvancedSettings, CloseOnClickModal = _b.CloseOnClickModal, CloseOnPressEscape = _b.CloseOnPressEscape, ShowInput = _b.ShowInput, InputPlaceholder = _b.InputPlaceholder, InputType = _b.InputType, Center = _b.Center, RoundButton = _b.RoundButton, InputBoxResult = _b.InputBoxResult, DistinguishCancelAndClose = _b.DistinguishCancelAndClose;
            console.log(this.CommandParam);
            var title = this.evaluateFormula(Title);
            var message = this.evaluateFormula(Message);
            var type = this.evaluateFormula(Type);
            var showConfirmButton = !!ShowConfirmButton;
            var confirmButtonText = this.evaluateFormula(ConfirmButtonText);
            var showCancelButton = !!ShowCancelButton;
            var cancelButtonText = this.evaluateFormula(CancelButtonText);
            var showClose = !!ShowClose;
            var closeOnClickModal = !!CloseOnClickModal;
            var closeOnPressEscape = !!CloseOnPressEscape;
            var showInput = !!ShowInput;
            var inputPlaceholder = this.evaluateFormula(InputPlaceholder);
            var inputType = ShowMessBoxInputType[InputType];
            var center = !!Center;
            var roundButton = !!RoundButton;
            var distinguishCancelAndClose = !!DistinguishCancelAndClose;
            var callback = function (parameter, instance) {
                if (typeof parameter === "string") {
                    Forguncy.CommandHelper.setVariableValue(DialogResult, parameter);
                }
                else {
                    Forguncy.CommandHelper.setVariableValue(DialogResult, parameter.action);
                    Forguncy.CommandHelper.setVariableValue(InputBoxResult, parameter.value);
                }
                _this.CommandExecutingInfo.suspend = false;
            };
            Forguncy.PageBuilder.hidePageLoadingCover();
            window.ElementPlus.ElMessageBox({
                title: title,
                message: message,
                type: type,
                showClose: showClose,
                showConfirmButton: showConfirmButton,
                confirmButtonText: confirmButtonText,
                showCancelButton: showCancelButton,
                cancelButtonText: cancelButtonText,
                closeOnClickModal: closeOnClickModal,
                closeOnPressEscape: closeOnPressEscape,
                showInput: showInput,
                inputPlaceholder: inputPlaceholder,
                inputType: inputType,
                center: center,
                roundButton: roundButton,
                callback: callback,
                distinguishCancelAndClose: distinguishCancelAndClose,
                customClass: "fgc-el-message-box"
            });
            this.CommandExecutingInfo.suspend = true;
        };
        return ShowMessageBox;
    }(ElementCommands.ElementCommandBase));
    ElementCommands.ShowMessageBox = ShowMessageBox;
    window.addEventListener("popstate", function () { return $(".fgc-el-message-box").parents(".el-overlay.is-message-box").remove(); });
})(ElementCommands || (ElementCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ElementUI.Commands.ShowMessageBox, ElementUI", ElementCommands.ShowMessageBox);
/// <reference path = "ELCommandBase.ts" />
var ElementCommands;
(function (ElementCommands) {
    var ShowNotification = /** @class */ (function (_super) {
        __extends(ShowNotification, _super);
        function ShowNotification() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ShowNotification.prototype.execute = function () {
            var _this = this;
            var _a, _b, _c, _d;
            var _e = this.CommandParam, Title = _e.Title, Duration = _e.Duration, Message = _e.Message, Context = _e.Context, Position = _e.Position, ShowClose = _e.ShowClose, Type = _e.Type, Offset = _e.Offset, Command = _e.Command;
            var duration = (_a = this.evaluateFormula(Duration)) !== null && _a !== void 0 ? _a : 0;
            var title = this.evaluateFormula(Title);
            var offset = (_b = Number(this.evaluateFormula(Offset))) !== null && _b !== void 0 ? _b : 0;
            var type = this.evaluateFormula(Type);
            var message = (_c = this.evaluateFormula(Message)) !== null && _c !== void 0 ? _c : type;
            var context = this.evaluateFormula(Context);
            var position = (_d = this.evaluateFormula(Position)) !== null && _d !== void 0 ? _d : "top-right";
            var clickCommands = Command;
            var showClose = !!ShowClose;
            var onClick = null;
            var customClass;
            var noticy = null;
            if ((clickCommands === null || clickCommands === void 0 ? void 0 : clickCommands.Commands) && clickCommands.Commands.length > 0) {
                onClick = function () {
                    var param = {};
                    param[clickCommands.ParamProperties["title"]] = title;
                    param[clickCommands.ParamProperties["message"]] = message;
                    param[clickCommands.ParamProperties["context"]] = context;
                    _this.executeCustomCommandObject(clickCommands, param, "Notice");
                    noticy.close();
                };
                customClass = "fgc-notice-element-clickable";
            }
            noticy = window.ElementPlus.ElNotification({
                title: title,
                message: message,
                type: type,
                duration: duration,
                position: position,
                showClose: showClose,
                offset: offset,
                onClick: onClick,
                customClass: customClass
            });
        };
        return ShowNotification;
    }(ElementCommands.ElementCommandBase));
    ElementCommands.ShowNotification = ShowNotification;
})(ElementCommands || (ElementCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ElementUI.Commands.ShowNotification, ElementUI", ElementCommands.ShowNotification);
var ElementCellTypes;
(function (ElementCellTypes) {
    var DateUtil = /** @class */ (function () {
        function DateUtil() {
        }
        DateUtil.isInvalidDate = function (date) {
            return !date || !date.getTime();
        };
        DateUtil.InteralConvertToDate = function (value) {
            if (!value) {
                return null;
            }
            if (value instanceof Date) {
                return value;
            }
            var numerValue = Number(value);
            var isOADate = !isNaN(numerValue);
            if (isOADate) {
                return Forguncy.ConvertOADateToDate(numerValue);
            }
            return new Date(value);
        };
        /**
         * 将时间转为日期
         * @param value
         */
        DateUtil.InteralConvertTimeToDate = function (value) {
            var date = DateUtil.InteralConvertToDate(value);
            return this.isInvalidDate(date) ? new Date("1970/1/1 ".concat(value)) : date;
        };
        /**
         * 将一个值转为一个日期
         * @param value
         * @param effectiveValue    转换失败时返回的值，默认是 Invalid Date
         */
        DateUtil.ConvertToDate = function (value, effectiveValue) {
            if (effectiveValue === void 0) { effectiveValue = "Invalid Date"; }
            var date = DateUtil.InteralConvertToDate(value);
            return this.isInvalidDate(date) ? effectiveValue : date;
        };
        /**
         * 将一个时间转为一个Date
         * @param value             时间字符串
         * @param options           传入年月日，默认是1970年1月1号
         * @param effectiveValue    转换失败时返回的值，默认是 Invalid Date
         */
        DateUtil.ConverTimeToDate = function (value, options, effectiveValue) {
            if (effectiveValue === void 0) { effectiveValue = "Invalid Date"; }
            var date = DateUtil.InteralConvertTimeToDate(value);
            if (this.isInvalidDate(date)) {
                return effectiveValue;
            }
            if (options.year) {
                date.setFullYear(options.year);
            }
            if (options.month || options.month === 0) {
                date.setMonth(options.month);
            }
            if (options.day) {
                date.setDate(options.day);
            }
            return date;
        };
        return DateUtil;
    }());
    ElementCellTypes.DateUtil = DateUtil;
})(ElementCellTypes || (ElementCellTypes = {}));
var ElementUtils;
(function (ElementUtils) {
    var dayjs = window.ElementPlus.dayjs;
    var Dayjs = /** @class */ (function () {
        function Dayjs() {
        }
        Dayjs._createLocale = function (options) {
            var _a;
            var localeName = (++Dayjs._localeIndex).toString();
            var locale = __assign(__assign({ name: (_a = options.name) !== null && _a !== void 0 ? _a : localeName }, dayjs[Dayjs._defaultLocaleName]), options);
            dayjs.locale(locale, null, true);
            Dayjs._localeCache.set(JSON.stringify(options), localeName);
            return localeName;
        };
        Dayjs._delayResetLocale = function () {
            setTimeout(function () { return dayjs.locale(Dayjs._defaultLocaleName); });
        };
        Dayjs.toggleLocale = function (options) {
            var _a;
            var localeName = (_a = Dayjs._localeCache.get(JSON.stringify(options))) !== null && _a !== void 0 ? _a : Dayjs._createLocale(options);
            dayjs.locale(localeName);
            Dayjs._delayResetLocale();
        };
        Dayjs._localeIndex = 0;
        Dayjs._localeCache = new Map();
        Dayjs._defaultLocaleName = dayjs.locale();
        return Dayjs;
    }());
    ElementUtils.Dayjs = Dayjs;
})(ElementUtils || (ElementUtils = {}));
var ElementCellTypes;
(function (ElementCellTypes) {
    ElementCellTypes.ElementIconMap = new Map();
    ElementCellTypes.ElementIconMap.set("plus", "<svg class=\"icon\" width=\"200\" height=\"200\" viewBox=\"0 0 1024 1024\" xmlns=\"http://www.w3.org/2000/svg\" data-v-042ca774=\"\"><path fill=\"currentColor\" d=\"M480 480V128a32 32 0 0164 0v352h352a32 32 0 110 64H544v352a32 32 0 11-64 0V544H128a32 32 0 010-64h352z\"></path></svg>");
})(ElementCellTypes || (ElementCellTypes = {}));
