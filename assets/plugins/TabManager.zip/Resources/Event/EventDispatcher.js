﻿var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
var TabManager;
(function (TabManager) {
    var EventDispatcher = (function () {
        function EventDispatcher() {
            this._events = new TabManager.Events();
        }
        EventDispatcher.prototype.on = function (eventName, handler) {
            this._events.addHandler(eventName, handler);
        };
        EventDispatcher.prototype.off = function (eventName, handler) {
            this._events.removeHandler(eventName, handler);
        };
        EventDispatcher.prototype.dispatch = function (eventName) {
            var _a;
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            (_a = this._events).raiseEvent.apply(_a, __spreadArray([eventName], args));
        };
        EventDispatcher.prototype.dispose = function () {
            this._events.release();
        };
        return EventDispatcher;
    }());
    TabManager.EventDispatcher = EventDispatcher;
})(TabManager || (TabManager = {}));
