var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ActiveReportsViewerCommand;
(function (ActiveReportsViewerCommand_1) {
    var ActiveReportsViewerCommand = (function (_super) {
        __extends(ActiveReportsViewerCommand, _super);
        function ActiveReportsViewerCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ActiveReportsViewerCommand.prototype.execute = function () {
            var model = this.CommandParam;
            this.preHandleCommandParam(model);
            if (model.MainFilePath) {
                this.preHandlePassValueItems(model);
                new ARJSExecutor().execute(model);
            }
        };
        ActiveReportsViewerCommand.prototype.preHandlePassValueItems = function (model) {
            var _this = this;
            var _a;
            (_a = model.PassValueItems) === null || _a === void 0 ? void 0 : _a.forEach(function (v) {
                v.ActualSource = _this.evaluateFormula(v.Source);
                v.ActualTarget = _this.evaluateFormula(v.Target);
            });
        };
        ActiveReportsViewerCommand.prototype.preHandleCommandParam = function (model) {
            var baseUrl = Forguncy.Helper.SpecialPath.getBaseUrl();
            model.ForguncyBaseUrl = window.location.origin + baseUrl;
            if (model.Files) {
                var arFiles = model.Files.filter(function (v) { return (v === null || v === void 0 ? void 0 : v.slice(-10)) === ".rdlx-json"; });
                if (arFiles.length > 0) {
                    var fileName = baseUrl + "customApi/activereportsapi/GetDesignerFile/" + arFiles[0];
                    model.MainFilePath = fileName;
                    model.MainFileTitle = arFiles[0].split(".rdlx-json")[0];
                    return;
                }
            }
            alert("未找到任何 rdlx-json 文件，请在设计器中至少上传一个报表文件。");
        };
        return ActiveReportsViewerCommand;
    }(Forguncy.Plugin.CommandBase));
    ActiveReportsViewerCommand_1.ActiveReportsViewerCommand = ActiveReportsViewerCommand;
    var ARJSExecutor = (function () {
        function ARJSExecutor() {
        }
        ARJSExecutor.prototype.execute = function (model) {
            this.saveSessions(model);
            this.openViewer(model);
        };
        ARJSExecutor.prototype.saveSessions = function (model) {
            this.saveToSessionStorage("FGC_AR_Model", JSON.stringify(model));
        };
        ARJSExecutor.prototype.saveToSessionStorage = function (key, value) {
            if (value) {
                sessionStorage.setItem(key, value);
            }
            else {
                sessionStorage.removeItem(key);
            }
        };
        ARJSExecutor.prototype.openViewer = function (model) {
            var _a;
            var base = location.origin;
            var url = Forguncy.Helper.SpecialPath.getPluginRootPath("136d4e65-1df3-4d79-b22a-d475fa70499b") + "Resources/ARJS/index.html";
            var pageID = Forguncy.ForguncyData.pageInfo.pageID;
            if ((_a = window === null || window === void 0 ? void 0 : window.TabManager) === null || _a === void 0 ? void 0 : _a.TabContainer.getCurrentInstance(window, pageID)) {
                TabManager.TabContainer.addTab(new TabManager.Tab(undefined, "", base + url, model.MainFileTitle, 0), pageID);
            }
            else {
                window.open(url);
            }
        };
        return ARJSExecutor;
    }());
})(ActiveReportsViewerCommand || (ActiveReportsViewerCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("ActiveReportsViewerCommand.ActiveReportsViewerCommand, ActiveReportsViewerCommand", ActiveReportsViewerCommand.ActiveReportsViewerCommand);
