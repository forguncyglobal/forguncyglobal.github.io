GanttMaster.prototype.$lang["en"] = {
	GridEditor: {
		Tabel: {
			codeNameCol: "Code Name",
			nameCol: "Name",
			statusCol: "Status",
			startCol: "Start",
			endCol: "End",
			durationCol: "Dur.",
			actualStartCol: "Actual Start",
			actualEndCol: "Actual End",
			actualDurationCol: "A. Dur.",
			dependsCol: "Dep.",
			progressCol: "%",
			descriptionCol: "Description",
			assigsCol: "Assigs",

			codeNameColTitle: "Code Name",
			nameColTitle: "Task Name",
			statusColTitle: "Task Status",
			startColTitle: "Plan Start Date",
			endColTitle: "Plan End Date",
			durationColTitle: "Plan Duration",
			actualStartColTitle: "Actual Start Date",
			actualEndColTitle: "Actual End Date",
			actualDurationColTitle: "Actual Duration",
			dependsColTitle: "Depends",
			progressColTitle: "Progress",
			descriptionColTitle: "Description",
			assigsColTitle: "Resource Assignment",

			milestoneColTitle: "Milestone",
			startMilestoneColTitle: "Start date is a milestone.",
			endMilestoneColTitle: "End date is a milestone."
		},
		TaskRow: {
			codeNamePlaceholder: "Code Name",
			namePlaceholder: "Name",
			defaultRootName: "Default Root Name"
		},
		Status: {
			STATUS_ACTIVE: "Active",
			STATUS_DONE: "Completed",
			STATUS_FAILED: "Failed",
			STATUS_SUSPENDED: "Suspended",
			STATUS_WAITING: "Waiting"
		},
		Error: {
			PLAN_DURATION_VALID: "The value must be a number with a minimum of 1",
			ACTUAL_DURATION_VALID: "The value can be empty or numeric with a minimum of 1"
		}
	},
	GridMaster: {
		ButtonBar: {
			addAboveCurrentTask: "Insert Above Task",
			addBelowCurrentTask: "Insert Below Task",
			outdentCurrentTask: "Outdent Task",
			indentCurrentTask: "Indent Task",
			moveUpCurrentTask: "Move Up Task",
			moveDownCurrentTask: "Move Down Task",
			deleteFocused: "Delete Task",
			expandAll: "Expand All Subtasks",
			collapseAll: "Collapse All Subtasks",
			zoomMinus: "Zoom Out",
			zoomPlus: "Zoom In",
			timeUnitMinus: "Decrease Time Unit",
			timeUnitPlus: "Increase Time Uni",
			toggleShowCriticalPath: "Critical Path",
			splitterLeft: "Splitter To Left",
			splitterMiddle: "Splitter To Middle",
			splitterRight: "Splitter To Right",
			toggleColorByStatus: "Toggle Status Color",
			switchDiaplaySVG: "Switch Show Actual",
			saveGanttData: "Save"
		},
		Custom: {
			msgError: "ERROR:"
		}
	},
	Error: {
		CANNOT_WRITE: "No permission to change the following task:",
		CHANGE_OUT_OF_SCOPE: "Project update not possible as you lack rights for updating a parent project.",
		START_IS_MILESTONE: "Start date is a milestone.",
		END_IS_MILESTONE: "End date is a milestone.",
		TASK_HAS_CONSTRAINTS: "Task has constraints: It has predecessors or it is the first child task of the parent task",
		GANTT_ERROR_DEPENDS_ON_OPEN_TASK: "Error: there is a dependency on an open task.",
		GANTT_ERROR_DESCENDANT_OF_CLOSED_TASK: "Error: due to a descendant of a closed task.",
		TASK_HAS_EXTERNAL_DEPS: "This task has external dependencies.",
		GANNT_ERROR_LOADING_DATA_TASK_REMOVED: "GANNT_ERROR_LOADING_DATA_TASK_REMOVED",
		CIRCULAR_REFERENCE: "Circular reference.",
		CANNOT_DEPENDS_ON_ANCESTORS: "Cannot depend on ancestors.",
		INVALID_DATE_FORMAT: "The data inserted are invalid for the field format.",
		GANTT_ERROR_LOADING_DATA_TASK_REMOVED: "An error has occurred while loading the data. A task has been trashed.",
		CANNOT_CLOSE_TASK_IF_OPEN_ISSUE: "Cannot close a task with open issues",
		TASK_MOVE_INCONSISTENT_LEVEL: "You cannot exchange tasks of different depth.",
		CANNOT_MOVE_TASK: "CANNOT_MOVE_TASK",
		PLEASE_SAVE_PROJECT: "PLEASE_SAVE_PROJECT",
		GANTT_SEMESTER: "Semester",
		GANTT_SEMESTER_SHORT: "s.",
		GANTT_QUARTER: "Quarter",
		GANTT_QUARTER_SHORT: "q.",
		GANTT_WEEK: "Week",
		GANTT_WEEK_SHORT: "w.",
		CANNOT_END_TIME_LESS_THAN_START_TIME: "The start time cannot be less than the end time",
		TASK_HAS_PERDECESSORS: "Task has constraints: It has predecessors.",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_EARLY: "Task has constraints: because its parent has predecessors, so the start time of this task cannot be earlier than then start time of its parent task.",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_MORE: "Task has constraints: bacause its parent has predecessors, so there must be a child task whose start time is the same as that of its parent task.",
		TASK_HAS_SUBTASKS_START_TIME: "Task has subtasks, and its start time is subject to the earliest start time of the subtask.",
		TASK_HAS_SUBTASKS_END_TIME: "Task has subtasks, and its end time is subject to the lastest end time of the subtask.",
		CANNOT_ADD_ABOVE_ROOT_TASK: "Cannot add brothers to root.",
		CANNOT_OUTDENT_ROOT_TASK: "Cannot outdent the root task level.",
		ONLY_CAN_HAVE_ONE_ROOT_TASK: "There can only be one root task.",
		CANNOT_INDENT_ROOT_TASK: "Cannot indent the root task level.",
		INDENT_TASK_MAXIMUM: "Task indented to the maximum extent: as a subtask of the previous task.",
		CANNOT_MOVE_ROOT_TASK: "Cannot move the root task.",
		TASK_MOVED_TO_TOP_SIBLING: "Task moved to top of sibling.",
		TASK_MOVED_TO_LAST_SIBLING: "Task moved to last of sibling.",
		SELECT_THE_TASK_TO_DELETE: "Please select the task to delete",
		CANNOT_DELETE_ROOT_TASK: "Cannot delete the root task."
	},
	Date: {
		DefaultFormat: "MM/dd/yyyy",
		MonthNames: {
			Jan: "January",
			Feb: "February",
			Mar: "March",
			Apr: "April",
			May: "May",
			Jun: "June",
			Jul: "July",
			Aug: "August",
			Sep: "September",
			Oct: "October",
			Nov: "November",
			Dec: "December"
		},
		MonthAbbreviations: {
			Jan: "Jan",
			Feb: "Feb",
			Mar: "Mar",
			Apr: "Apr",
			May: "May",
			Jun: "Jun",
			Jul: "Jul",
			Aug: "Aug",
			Sep: "Sep",
			Oct: "Oct",
			Nov: "Nov",
			Dec: "Dec"
		},
		DayNames: {
			Sun: "Sunday",
			Mon: "Monday",
			Tue: "Tuesday",
			Wed: "Wednesday",
			Thu: "Thursday",
			Fri: "Friday",
			Sat: "Saturday"
		},
		DayAbbreviations: {
			Sun: "Sun",
			Mon: "Mon",
			Tue: "Tue",
			Wed: "Wed",
			Thu: "Thu",
			Fri: "Fri",
			Sat: "Sat"
		}
	},
	Zoom: {
		ThreeDays: {
			Row1: "{ startMonth } { startDate } - { dateMonth } { dateDay } { dateYear } ({ whickWeek })",
			Row2: "{ startDay }({ startDate })"
		},
		OneWeek: {
			Row1: "{ startMonth } { startDate } - { dateMonth } { dateDay } { dateYear } ({ whickWeek })",
			Row2: "{ startDay }({ startDate })"
		},
		TwoWeek: {
			Row1: "{ startMonth } { startDate } - { dateMonth } { dateDay } { dateYear } ({ whickWeek })",
			Row2: "{ startDay }"
		},
		OneMonth: {
			Row1: "{ startMonth } { startYear }",
			Row2: "{ startDate }"
		},
		OneQuarter: {
			Row1: "{ startQuarter } { startYear }",
			Row2: "{ startMonth }"
		},
		TwoQuarter: {
			Row1: "{ startQuarter } { startYear }",
			Row2: "{ startMonth }"
		},
		OneYear: {
			Row1: "{ HalfYear } { startYear }",
			Row2: "{ startMonth }"
		},
		TwoYear: {
			Row1: "{ startYear }",
			Row2: "{ HalfYear }"
		},
		WhickWeek: "Week {0}",
		MonthAbbreviationsNumber: {
			0: "Jan",
			1: "Feb",
			2: "Mar",
			3: "Apr",
			4: "May",
			5: "Jun",
			6: "Jul",
			7: "Aug",
			8: "Sep",
			9: "Oct",
			10: "Nov",
			11: "Dec"
		},
		DayNamesNumber: {
			0: "Sun",
			1: "Mon",
			2: "Tue",
			3: "Wed",
			4: "Thu",
			5: "Fri",
			6: "Sat"
		},
		DayAbbreviationsNumber: {
			0: "Sun",
			1: "Mon",
			2: "Tue",
			3: "Wed",
			4: "Thu",
			5: "Fri",
			6: "Sat"
		},
		QuarterNumber: {
			0: "Quarter 1",
			1: "Quarter 2",
			2: "Quarter 3",
			3: "Quarter 4"
		},
		HalfYearNumber: {
			0: "Semester 1",
			1: "Semester 2"
		}
	}
};
