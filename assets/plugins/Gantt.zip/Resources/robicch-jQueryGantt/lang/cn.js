GanttMaster.prototype.$lang["cn"] = {
	GridEditor: {
		Tabel: {
			codeNameCol: "代号",
			nameCol: "名称",
			statusCol: "状态",
			startCol: "开始时间",
			endCol: "结束时间",
			durationCol: "工期",
			actualStartCol: "实际开始时间",
			actualEndCol: "实际结束时间",
			actualDurationCol: "实际工期",
			dependsCol: "前置任务",
			progressCol: "%",
			descriptionCol: "描述",
			assigsCol: "资源",

			codeNameColTitle: "任务代号",
			nameColTitle: "任务名称",
			statusColTitle: "任务状态",
			startColTitle: "计划开始时间",
			endColTitle: "计划结束时间",
			durationColTitle: "计划工期",
			actualStartColTitle: "实际开始时间",
			actualEndColTitle: "实际结束时间",
			actualDurationColTitle: "实际工期",
			dependsColTitle: "前置任务",
			progressColTitle: "任务进度",
			descriptionColTitle: "任务描述",
			assigsColTitle: "任务资源",

			milestoneColTitle: "里程碑",
			startMilestoneColTitle: "开始时间是一个里程碑",
			endMilestoneColTitle: "结束时间是一个里程碑"
		},
		TaskRow: {
			codeNamePlaceholder: "代号",
			namePlaceholder: "名称",
			defaultRootName: "默认根任务名称"
		},
		Status: {
			STATUS_ACTIVE: "进行中",
			STATUS_DONE: "已完成",
			STATUS_FAILED: "已失败",
			STATUS_SUSPENDED: "准备中",
			STATUS_WAITING: "等待中"
		},
		Error: {
			PLAN_DURATION_VALID: "值必须为数字且最小为 1",
			ACTUAL_DURATION_VALID: "值可为空，或者为数字且最小为 1"
		}
	},
	GridMaster: {
		ButtonBar: {
			addAboveCurrentTask: "在上一行添加任务",
			addBelowCurrentTask: "在下一行添加任务",
			outdentCurrentTask: "提高一层任务层级",
			indentCurrentTask: "降低一层任务层级",
			moveUpCurrentTask: "向上一层移动任务",
			moveDownCurrentTask: "向下一层移动任务",
			deleteFocused: "删除任务",
			expandAll: "展开子任务",
			collapseAll: "折叠子任务",
			zoomMinus: "增大视图",
			zoomPlus: "减少视图",
			timeUnitMinus: "减少时间单位",
			timeUnitPlus: "增大时间单位",
			toggleShowCriticalPath: "显/隐关键任务路径",
			splitterLeft: "分隔线置于最左边",
			splitterMiddle: "分隔线置于中间",
			splitterRight: "分隔线置于右边",
			toggleColorByStatus: "切换状态颜色",
			switchDiaplaySVG: "显/隐实际图",
			saveGanttData: "保存"
		},
		Custom: {
			msgError: "错误："
		}
	},
	Error: {
		CANNOT_WRITE: "没有权限去修改这些任务：",
		CHANGE_OUT_OF_SCOPE: "无法更新项目：缺乏更新父项目的权限",
		START_IS_MILESTONE: "开始时间是一个里程碑",
		END_IS_MILESTONE: "结束时间是一个里程碑",
		TASK_HAS_CONSTRAINTS: "任务被约束：拥有前置任务",
		GANTT_ERROR_DEPENDS_ON_OPEN_TASK: "错误：打开的任务被依赖。",
		GANTT_ERROR_DESCENDANT_OF_CLOSED_TASK: "错误：关闭的任务有子任务",
		TASK_HAS_EXTERNAL_DEPS: "这个任务有外部依赖。",
		GANNT_ERROR_LOADING_DATA_TASK_REMOVED: "错误：加载已移除的任务",
		CIRCULAR_REFERENCE: "循环依赖",
		CANNOT_DEPENDS_ON_ANCESTORS: "不能依赖祖先",
		INVALID_DATE_FORMAT: "插入的数据对于字段格式无效",
		GANTT_ERROR_LOADING_DATA_TASK_REMOVED: "加载数据时发生错误：一项任务已被删除。",
		CANNOT_CLOSE_TASK_IF_OPEN_ISSUE: "无法关闭有未解决问题的任务",
		TASK_MOVE_INCONSISTENT_LEVEL: "不能交换不同层级的任务",
		CANNOT_MOVE_TASK: "不能移动任务",
		PLEASE_SAVE_PROJECT: "PLEASE_SAVE_PROJECT请保存项目",
		GANTT_SEMESTER: "短学期",
		GANTT_SEMESTER_SHORT: "短学期",
		GANTT_QUARTER: "季度",
		GANTT_QUARTER_SHORT: "季度",
		GANTT_WEEK: "周",
		GANTT_WEEK_SHORT: "周",
		CANNOT_END_TIME_LESS_THAN_START_TIME: "结束时间不能小于开始时间",
		TASK_HAS_PERDECESSORS: "任务被约束：拥有前置任务",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_EARLY: "任务被约束：因为其父任务拥有前置任务，故此任务的开始时间不能早于其父任务的开始时间",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_MORE: "任务被约束：因为其父任务拥有前置任务，故必须有一个子任务的开始时间相同于其父任务的开始时间",
		TASK_HAS_SUBTASKS_START_TIME: "任务拥有子任务，其开始时间以子任务最早开始时间为准",
		TASK_HAS_SUBTASKS_END_TIME: "任务拥有子任务，其结束时间以子任务最晚结束时间为准",
		CANNOT_ADD_ABOVE_ROOT_TASK: "不能在根任务之前添加任务",
		CANNOT_OUTDENT_ROOT_TASK: "不能提高根任务层级",
		ONLY_CAN_HAVE_ONE_ROOT_TASK: "只能有一个根任务",
		CANNOT_INDENT_ROOT_TASK: "不能降低根任务层级",
		INDENT_TASK_MAXIMUM: "任务已缩进到最大程度：作为上一个任务的子任务",
		CANNOT_MOVE_ROOT_TASK: "不能移动根任务",
		TASK_MOVED_TO_TOP_SIBLING: "任务已移动到同级最前",
		TASK_MOVED_TO_LAST_SIBLING: "任务已移动到同级最后",
		SELECT_THE_TASK_TO_DELETE: "请选择要删除的任务",
		CANNOT_DELETE_ROOT_TASK: "不能删除根任务"
	},
	Date: {
		DefaultFormat: "yyyy/MM/dd",
		MonthNames: {
			Jan: "一月",
			Feb: "二月",
			Mar: "三月",
			Apr: "四月",
			May: "五月",
			Jun: "六月",
			Jul: "七月",
			Aug: "八月",
			Sep: "九月",
			Oct: "十月",
			Nov: "十一月",
			Dec: "十二月"
		},
		MonthAbbreviations: {
			Jan: "一月",
			Feb: "二月",
			Mar: "三月",
			Apr: "四月",
			May: "五月",
			Jun: "六月",
			Jul: "七月",
			Aug: "八月",
			Sep: "九月",
			Oct: "十月",
			Nov: "十一月",
			Dec: "十二月"
		},
		DayNames: {
			Sun: "周日",
			Mon: "周一",
			Tue: "周二",
			Wed: "周三",
			Thu: "周四",
			Fri: "周五",
			Sat: "周六"
		},
		DayAbbreviations: {
			Sun: "日",
			Mon: "一",
			Tue: "二",
			Wed: "三",
			Thu: "四",
			Fri: "五",
			Sat: "六"
		}
	},
	Zoom: {
		ThreeDays: {
			Row1: "{ dateYear } ({ whickWeek }) { startMonth }.{ startDate }-{ dateMonth }.{ dateDay }",
			Row2: "{ startDay }({ startDate })"
		},
		OneWeek: {
			Row1: "{ dateYear } ({ whickWeek }) { startMonth }.{ startDate }-{ dateMonth }.{ dateDay }",
			Row2: "{ startDay }({ startDate })"
		},
		TwoWeek: {
			Row1: "{ dateYear } ({ whickWeek }) { startMonth }.{ startDate }-{ dateMonth }.{ dateDay }",
			Row2: "{ startDay }"
		},
		OneMonth: {
			Row1: "{ startYear } { startMonth }",
			Row2: "{ startDate }"
		},
		OneQuarter: {
			Row1: "{ startYear } { startQuarter }",
			Row2: "{ startMonth }"
		},
		TwoQuarter: {
			Row1: "{ startYear } { startQuarter }",
			Row2: "{ startMonth }"
		},
		OneYear: {
			Row1: "{ startYear } { HalfYear }",
			Row2: "{ startMonth }"
		},
		TwoYear: {
			Row1: "{ startYear }",
			Row2: "{ HalfYear }"
		},
		WhickWeek: "第 {0} 周",
		MonthAbbreviationsNumber: {
			0: "1",
			1: "2",
			2: "3",
			3: "4",
			4: "5",
			5: "6",
			6: "7",
			7: "8",
			8: "9",
			9: "10",
			10: "11",
			11: "12"
		},
		DayNamesNumber: {
			0: "周日",
			1: "周一",
			2: "周二",
			3: "周三",
			4: "周四",
			5: "周五",
			6: "周六"
		},
		DayAbbreviationsNumber: {
			0: "日",
			1: "一",
			2: "二",
			3: "三",
			4: "四",
			5: "五",
			6: "六"
		},
		QuarterNumber: {
			0: "第一季度",
			1: "第二季度",
			2: "第三季度",
			3: "第四季度"
		},
		HalfYearNumber: {
			0: "上半年",
			1: "下半年"
		}
	}
};
