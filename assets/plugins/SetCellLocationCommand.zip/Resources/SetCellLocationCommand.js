var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SetCellLocationCommand;
(function (SetCellLocationCommand_1) {
    var SetCellLocationCommand = (function (_super) {
        __extends(SetCellLocationCommand, _super);
        function SetCellLocationCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SetCellLocationCommand.prototype.execute = function () {
            var setCellLoationParam = this.CommandParam;
            var cellLocation = this.getCellLocation(setCellLoationParam.SourceCell);
            var cellId = this.getIdStr(cellLocation.Row, cellLocation.Column, cellLocation.PageID);
            this.setLocation(setCellLoationParam.CellLocation, cellId);
        };
        SetCellLocationCommand.prototype.setLocation = function (formula, id) {
            var _a, _b;
            var cell = Forguncy.ForguncyData.pageInfo.pageElementManager.cells.getCell(id);
            if (!cell) {
                return false;
            }
            var locations = Forguncy.FormulaHelper.getRangeLocations(formula, this.CommandExecutingInfo.runTimePageName);
            if (!locations || locations.length <= 0) {
                return;
            }
            var location = locations[0];
            if (!location || location.Row < 0 || location.Column < 0) {
                return;
            }
            cell.layout.Row = location.Row;
            cell.layout.Column = location.Column;
            cell.layout.RowSpan = ((_a = location.EndRow) !== null && _a !== void 0 ? _a : location.Row) - location.Row + 1;
            cell.layout.ColumnSpan = ((_b = location.EndColumn) !== null && _b !== void 0 ? _b : location.Column) - location.Column + 1;
            var layout = Forguncy.ForguncyData.pageInfo.pageLayouts[this.CommandExecutingInfo.runTimePageName];
            layout.lazyLocateElements();
        };
        SetCellLocationCommand.prototype.getIdStr = function (row, col, idSuffix) {
            return 'r' + row + 'c' + col + idSuffix;
        };
        return SetCellLocationCommand;
    }(Forguncy.Plugin.CommandBase));
    SetCellLocationCommand_1.SetCellLocationCommand = SetCellLocationCommand;
})(SetCellLocationCommand || (SetCellLocationCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("SetCellLocationCommand.SetCellLocationCommand, SetCellLocationCommand", SetCellLocationCommand.SetCellLocationCommand);
