var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    var ServeBaseUrl = (function () {
        function ServeBaseUrl() {
        }
        ServeBaseUrl.getDownloadUrl = function () {
            return window.location.origin + Forguncy.Helper.SpecialPath.getBaseUrl() + "FileDownloadUpload/Download?file=";
        };
        ServeBaseUrl.getUploadUrl = function () {
            return window.location.origin + Forguncy.Helper.SpecialPath.getBaseUrl() + "FileDownloadUpload/Upload";
        };
        return ServeBaseUrl;
    }());
    var ServerFileItem = (function (_super) {
        __extends(ServerFileItem, _super);
        function ServerFileItem(raw) {
            var _this = _super.call(this, ServeBaseUrl.getDownloadUrl() + raw) || this;
            _this.raw = raw;
            return _this;
        }
        ServerFileItem.prototype.getEncodeURIComponentSrc = function () {
            return ServeBaseUrl.getDownloadUrl() + encodeURIComponent(this.raw);
        };
        ServerFileItem.prototype.getStorageSrc = function () {
            return this.raw;
        };
        ServerFileItem.prototype.getFileName = function () {
            return this.raw;
        };
        ServerFileItem.prototype.getDisplayFileName = function () {
            return this.getFileName().slice(37);
        };
        return ServerFileItem;
    }(FilePreviewer.FileItem));
    FilePreviewer.ServerFileItem = ServerFileItem;
    var ServerStorageService = (function () {
        function ServerStorageService(metadata) {
            this.metadata = metadata;
            if (!this.metadata.UploadLimit) {
                this.metadata.UploadLimit = {
                    ExtensionFilter: "",
                    MaxUploadFileCount: null,
                    SizeLimit: null
                };
            }
        }
        ServerStorageService.prototype.upload = function (file, transmit) {
            if (Forguncy.onFilePreviewerFileUpload) {
                var result = Forguncy.onFilePreviewerFileUpload.call(this, transmit, file, this.metadata.CellNames);
                if (result) {
                    return;
                }
            }
            this.uploadFileWithAjax(file, transmit);
        };
        ServerStorageService.prototype.download = function (url, onSuccess, onError) {
            var link = $("<a>download</a>").attr("href", url);
            $("body").append(link);
            link[0].click();
            link.remove();
            onSuccess && onSuccess();
        };
        ServerStorageService.prototype.delete = function (url, onSuccess, onError) {
            onSuccess && onSuccess();
        };
        ServerStorageService.prototype.uploadFileWithAjax = function (file, transmit) {
            var _a;
            var formData = new FormData();
            formData.append("file", file);
            formData.append("uploadLimitId", (_a = this.metadata.ServerPropertiesId) === null || _a === void 0 ? void 0 : _a.UploadLimit);
            $.ajax({
                url: ServeBaseUrl.getUploadUrl(),
                type: "POST",
                success: function (data, textStatus, jqXHR) { return transmit.success && transmit.success({ raw: file, fileItem: new ServerFileItem(jqXHR.responseText) }); },
                error: function (jqXHR, textStatus, errorThrown) { return transmit.fail && transmit.fail({ raw: file, errorMessage: errorThrown }); },
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                headers: {
                    "Accept": "application/json"
                },
                xhr: function () {
                    var xhr = $.ajaxSettings.xhr();
                    if (transmit.progress && xhr.upload) {
                        xhr.upload.addEventListener("progress", function (e) {
                            transmit.progress({ raw: file, loaded: e.loaded, total: e.total });
                        }, false);
                    }
                    return xhr;
                }
            });
        };
        return ServerStorageService;
    }());
    FilePreviewer.ServerStorageService = ServerStorageService;
})(FilePreviewer || (FilePreviewer = {}));
