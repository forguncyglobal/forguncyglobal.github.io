﻿window.ImageEditorResource.Language.EN = {
    Download:"Download",
    Save: "Save",
    Upload: "Upload",
    Error_IncorrectFileType: "The uploaded file {0} is of incorrect type."
};
