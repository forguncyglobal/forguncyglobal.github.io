var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ImportExportCSVCommand;
(function (ImportExportCSVCommand) {
    var ImportExportCSV = /** @class */ (function (_super) {
        __extends(ImportExportCSV, _super);
        function ImportExportCSV() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ImportExportCSV.prototype.execute = function () {
            // Get settings
            var commandSettings = this.CommandParam;
            var importExportInfo = commandSettings.ImportExportInfo;
            if (!importExportInfo) {
                return;
            }
            var csvOperation = importExportInfo.CSVOperation;
            var listViewName = importExportInfo.ListViewName;
            var importExportHeaderRow = importExportInfo.ImportExportHeaderRow;
            var columns = importExportInfo.Columns;
            var isAlert = importExportInfo.IsAlert;
            var alertMessage = importExportInfo.AlertMessage;
            var pageID = this.getFormulaCalcContext().PageID;
            var pageInfo = Forguncy.Page.getSubPageInfoByPageID(pageID);
            var listview = pageInfo ? pageInfo.getListView(listViewName) : Forguncy.Page.getListView(listViewName, false);
            var cellLocations = this.getCellLocations(columns);
            if (!listview || cellLocations.length <= 0) {
                return;
            }
            var isPrimaryKeys = columns.map(function (c) {
                return c.IsPrimaryKey;
            });
            var columnNames = importExportHeaderRow ?
                columns.map(function (c) {
                    return c.CSVColumnName.trim();
                }) :
                undefined;
            var csvColumnIndexs = importExportHeaderRow || csvOperation !== CSVOperation.Import ?
                undefined :
                columns.map(function (c) {
                    return c.CSVColumnIndex;
                });
            var columnIndexListInListView = this.getColumnIndexs(listview, cellLocations);
            this.suspendCommand();
            if (csvOperation === CSVOperation.Import) {
                this.importCSVFile({
                    listview: listview,
                    importExportHeaderRow: importExportHeaderRow,
                    columnNames: columnNames,
                    csvColumnIndexs: csvColumnIndexs,
                    columnIndexListInListView: columnIndexListInListView,
                    importMode: importExportInfo.ImportMode,
                    encodingType: this.evaluateFormula(importExportInfo.EncodingType),
                    lineDelimiter: this.calcLineDelemiterFormula(importExportInfo.LineDelimiter),
                    columnDelimiter: this.calcColumnDelemiterFormula(importExportInfo.ColumnDelimiter),
                    textQualifier: this.calcTextQualifier(importExportInfo.TextQualifier),
                    isPrimaryKeys: isPrimaryKeys,
                    fileExtension: this.evaluateFormula(importExportInfo.FileExtension)
                }, function () {
                    if (isAlert) {
                        alert(typeof alertMessage === "string" ? alertMessage : "");
                    }
                });
            }
            else {
                var exportFileName = this.evaluateFormula(importExportInfo.ExportFileName);
                if (exportFileName === null || exportFileName === undefined || ("" + exportFileName).trim() === "") {
                    exportFileName = listViewName;
                }
                this.exportCSVFile({
                    listview: listview,
                    importExportHeaderRow: importExportHeaderRow,
                    columnNames: columnNames,
                    columnIndexListInListView: columnIndexListInListView,
                    lineDelimiter: this.calcLineDelemiterFormula(importExportInfo.LineDelimiter),
                    columnDelimiter: this.calcColumnDelemiterFormula(importExportInfo.ColumnDelimiter),
                    textQualifier: this.calcTextQualifier(importExportInfo.TextQualifier),
                    forceTextQualifier: importExportInfo.UseQualifierForAllFields,
                    csvFileName: exportFileName,
                    fileExtension: this.evaluateFormula(importExportInfo.FileExtension)
                });
            }
        };
        ImportExportCSV.prototype.calcDelimiterFormula = function (delimiter) {
            var delimiterStr = this.evaluateFormula(delimiter);
            if (delimiterStr === null || delimiterStr === undefined || delimiterStr === "") {
                return undefined;
            }
            switch (delimiterStr) {
                case "\\t": return "\t";
                case "\\r\\n": return "\r\n";
                case "\\r": return "\r";
                case "\\n": return "\n";
                default: return delimiterStr.toString();
            }
        };
        ImportExportCSV.prototype.calcColumnDelemiterFormula = function (columnDelimiter) {
            return this.calcDelimiterFormula(columnDelimiter) || ",";
        };
        ImportExportCSV.prototype.calcLineDelemiterFormula = function (lineDelimiter) {
            return this.calcDelimiterFormula(lineDelimiter);
        };
        ImportExportCSV.prototype.calcTextQualifier = function (textQualifier) {
            if (textQualifier === "'") {
                return textQualifier;
            }
            return this.evaluateFormula(textQualifier) || "\"";
        };
        ImportExportCSV.prototype.getCellLocations = function (columns) {
            var list = [];
            if (columns) {
                for (var i = 0; i < columns.length; i++) {
                    var cell = columns[i].ListViewColumnCell;
                    if (typeof (cell) === "string" && cell.length > 0 && cell[0] === "=") {
                        cell = this.getCellLocation(cell);
                        list.push(cell);
                    }
                    else {
                        list.push(null);
                    }
                }
            }
            return list;
        };
        ImportExportCSV.prototype.getColumnIndexs = function (listview, cellLocations) {
            var columnIndexList = [];
            var columns = listview.getMergedColumnInfos();
            for (var i = 0; i < cellLocations.length; i++) {
                if (cellLocations[i] === null) {
                    columnIndexList.push(-1);
                    continue;
                }
                var columnIndex = cellLocations[i].Column;
                var j = 0;
                for (j = 0; j < columns.length; j++) {
                    if (columns[j].DesignerColumnIndex === columnIndex) {
                        columnIndexList.push(j);
                        break;
                    }
                }
                if (j === columns.length) {
                    columnIndexList.push(-1);
                }
            }
            return columnIndexList;
        };
        ImportExportCSV.prototype.getActualFileExtension = function (fileExtension) {
            var _a;
            fileExtension = (_a = fileExtension === null || fileExtension === void 0 ? void 0 : fileExtension.trim()) === null || _a === void 0 ? void 0 : _a.replace(/^\.+|\.+$/g, ""); // Trim('.')
            if (!fileExtension) {
                fileExtension = "csv";
            }
            return "." + fileExtension;
        };
        ImportExportCSV.prototype.importCSVFile = function (options, alertSuccessMessage) {
            var _this = this;
            if (this.CommandExecutingInfo.eventType === "pageloaded" && this.platformIsChrome()) {
                this.resumeCommand();
                return;
            }
            var self = this;
            if ($("#" + "importCSVFileInputID" /* importCSVFileInputID */).length > 0) {
                $("#" + "importCSVFileInputID" /* importCSVFileInputID */).remove();
            }
            var fileInput = $("<input id='" + "importCSVFileInputID" /* importCSVFileInputID */ + "' type='file'/>");
            fileInput.css("display", "none");
            var accept = this.getActualFileExtension(options.fileExtension);
            //FORGUNCY-287 [Mobile][Andriod]It prompt "no application to execute the operation" when clicking add button to upload file..
            if (this.isAndroid() && this.isWechatOrQQBrowser()) {
                accept = null;
            }
            // -------------------------------------------------------------------------
            fileInput.attr("accept", accept);
            $("body").append(fileInput);
            $("#" + "importCSVFileInputID" /* importCSVFileInputID */).change(function (e) {
                var fileName = e.target.files[0];
                if (!fileName) {
                    self.resumeCommand();
                    return;
                }
                options.listview.showLoadingIndicator();
                var reader = new FileReader();
                reader.readAsDataURL(fileName);
                reader.onload = function (evt) {
                    window.Papa.parse(fileName, {
                        header: options.importExportHeaderRow,
                        //dynamicTyping: true,
                        encoding: options.encodingType,
                        complete: function (results) {
                            var _a, _b, _c, _d, _e, _f;
                            try {
                                var headers = void 0, headersOfUniformLineBreak = void 0, columnNamesOfUniformLineBreak = void 0;
                                if (options.importExportHeaderRow) {
                                    headers = (_c = (_b = (_a = results === null || results === void 0 ? void 0 : results.meta) === null || _a === void 0 ? void 0 : _a.fields) === null || _b === void 0 ? void 0 : _b.map(function (f) { return f === null || f === void 0 ? void 0 : f.trim(); })) !== null && _c !== void 0 ? _c : [];
                                    headersOfUniformLineBreak = (_d = headers === null || headers === void 0 ? void 0 : headers.map(function (f) { return self.replaceLineBreaks(f); })) !== null && _d !== void 0 ? _d : [];
                                    columnNamesOfUniformLineBreak = (_f = (_e = options.columnNames) === null || _e === void 0 ? void 0 : _e.map(function (f) { return self.replaceLineBreaks(f); })) !== null && _f !== void 0 ? _f : [];
                                }
                                var checkResult = self.checkImportData(results, headersOfUniformLineBreak, options.importExportHeaderRow, columnNamesOfUniformLineBreak);
                                if (!checkResult) {
                                    options.listview.hiddenLoadingIndicator();
                                    self.resumeCommand();
                                    return;
                                }
                                var processedColumnNames = self.getProcessedColumnNames(headers, headersOfUniformLineBreak, options.importExportHeaderRow, columnNamesOfUniformLineBreak);
                                var data = self.getImportData(results.data, options.importExportHeaderRow, processedColumnNames, options.csvColumnIndexs, options.columnIndexListInListView);
                                var baseColumns = self.getListviewPrimaryKeyIndexes(options.columnIndexListInListView, options.isPrimaryKeys);
                                options.listview.importData(data, true, options.importMode, baseColumns, options.columnIndexListInListView, function (importResult) {
                                    if (importResult.Success) {
                                        alertSuccessMessage();
                                    }
                                    else {
                                        switch (importResult.ErrorInfos[0].ErrorType) {
                                            case Forguncy.ImportError.ExistSameKeys:
                                                alert(self.getRS().Error_ExistSameKeys);
                                                break;
                                            case Forguncy.ImportError.ValidateError:
                                                self.alertErrorMessage(importResult.ErrorInfos[0].ErrorData, options.importExportHeaderRow);
                                                break;
                                            default:
                                                break;
                                        }
                                    }
                                    options.listview.hiddenLoadingIndicator();
                                    self.resumeCommand();
                                });
                            }
                            catch (_g) {
                                options.listview.hiddenLoadingIndicator();
                                self.resumeCommand();
                            }
                        },
                        delimiter: options.columnDelimiter,
                        newline: options.lineDelimiter,
                        quoteChar: options.textQualifier,
                        error: function () {
                            self.resumeCommand();
                        }
                    });
                };
            }).one("click touchstart", function (e) {
                setTimeout(function () {
                    if (!_this._suspendCommand) {
                        return;
                    }
                    if (_this.platformIsChrome()) {
                        $(document).one("mousemove focusin", function () {
                            if (!_this._suspendCommand) {
                                return;
                            }
                            setTimeout(function () {
                                if ($("#" + "importCSVFileInputID" /* importCSVFileInputID */).val().length === 0) {
                                    _this.resumeCommand();
                                    /* that's the point of cancel,   */
                                }
                            }, 325);
                        });
                    }
                    else {
                        $(document).one("mousemove focusin", function () {
                            if (e.target.files.length === 0) {
                                _this.resumeCommand();
                                /* that's the point of cancel,   */
                            }
                        });
                    }
                }, 200);
            });
            if (!Forguncy.ForguncyData.IsAutoTest) {
                $("#" + "importCSVFileInputID" /* importCSVFileInputID */).click();
                $("#" + "importCSVFileInputID" /* importCSVFileInputID */).trigger("touchstart");
            }
        };
        ImportExportCSV.prototype.suspendCommand = function () {
            this.CommandExecutingInfo.suspend = true;
            this._suspendCommand = true;
        };
        ImportExportCSV.prototype.resumeCommand = function () {
            if (this._suspendCommand) {
                this._suspendCommand = false;
                this.CommandExecutingInfo.suspend = false;
            }
        };
        ImportExportCSV.prototype.getProcessedColumnNames = function (headers, headersOfUniformNewline, importExportHeaderRow, columnNames) {
            var _a;
            if (!importExportHeaderRow) {
                return columnNames;
            }
            return (_a = columnNames.map(function (val) { return headers[headersOfUniformNewline.indexOf(val)]; })) !== null && _a !== void 0 ? _a : [];
        };
        ImportExportCSV.prototype.checkImportData = function (result, headers, importExportHeaderRow, columnNames) {
            var success = this.checkHeaderRowInImportData(headers, importExportHeaderRow, columnNames);
            return success;
        };
        ImportExportCSV.prototype.checkHeaderRowInImportData = function (headers, importExportHeaderRow, columnNames) {
            if (!importExportHeaderRow) {
                return true;
            }
            var noFindColumns = columnNames.filter(function (c) { return headers.indexOf(c) === -1; });
            if (noFindColumns.length > 0) {
                alert(this.getRS().Error_ColumnNameNotMatch.replace("{0}", noFindColumns.join(",")));
                return false;
            }
            return true;
        };
        ImportExportCSV.prototype.replaceLineBreaks = function (str) {
            if (str === null || str === undefined || str === "") {
                return "";
            }
            return str.replace(/\r\n|\r/g, "\n");
        };
        ImportExportCSV.prototype.getImportData = function (csvData, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView) {
            var _this = this;
            //remove empty rows in the end.
            csvData = this.removeEmptyRowsInTheEnd(csvData);
            var data = csvData.map(function (row) {
                return _this.getNewRowData(row, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView);
            });
            return data;
        };
        ImportExportCSV.prototype.removeEmptyRowsInTheEnd = function (data) {
            var invalidRowCount = 0;
            for (var i = data.length - 1; i >= 0; i--) {
                var newRowData = data[i];
                if (!newRowData || newRowData.length === 0) {
                    invalidRowCount++;
                    continue;
                }
                var isEmptyRow = true;
                for (var key in newRowData) {
                    if (newRowData[key] !== undefined && newRowData[key] !== null && newRowData[key] !== "") {
                        isEmptyRow = false;
                        break;
                    }
                }
                if (isEmptyRow) {
                    invalidRowCount++;
                }
                else {
                    break;
                }
            }
            if (invalidRowCount > 0) {
                var validRowCount = data.length - invalidRowCount;
                data = data.slice(0, validRowCount);
            }
            return data;
        };
        ImportExportCSV.prototype.getListviewPrimaryKeyIndexes = function (columnIndexListInListView, isPrimaryKeys) {
            return isPrimaryKeys
                .map(function (isPrimaryKey, index) { return isPrimaryKey ? columnIndexListInListView[index] : -1; })
                .filter(function (col) { return col !== -1; });
        };
        ImportExportCSV.prototype.getRS = function () {
            var culture = Forguncy.RS.Culture;
            if (culture === 'CN') {
                return window.RS_CN;
            }
            else if (culture === 'JA') {
                return window.RS_JP;
            }
            else if (culture === 'KR') {
                return window.RS_KO;
            }
            return window.RS_EN;
        };
        ImportExportCSV.prototype.getNewRowData = function (rowData, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView) {
            var newRowData = [];
            for (var i = 0; i < columnIndexListInListView.length; i++) {
                var c = columnIndexListInListView[i];
                if (c === -1) {
                    continue;
                }
                var cNameOrIndex = importExportHeaderRow === true ? columnNames[i] : csvColumnIndexs[i] - 1;
                var tempValue = rowData[cNameOrIndex];
                if (tempValue === null || tempValue === undefined || tempValue === "") {
                    tempValue = null;
                }
                newRowData[c] = tempValue;
            }
            return newRowData;
        };
        ImportExportCSV.prototype.alertErrorMessage = function (errorData, importExportHeaderRow) {
            var csvRowIndex = errorData.RowIndex + 1;
            if (importExportHeaderRow) {
                csvRowIndex += 1;
            }
            alert(this.getRS().Error_DetailInfo.replace("{0}", errorData.CellValue).replace("{1}", csvRowIndex).replace("{2}", errorData.Message));
        };
        ImportExportCSV.prototype.isAndroid = function () {
            var userAgent = navigator.userAgent.toLowerCase();
            return userAgent.indexOf("android") > -1 || userAgent.indexOf("adr") > -1;
        };
        ImportExportCSV.prototype.isWechatOrQQBrowser = function () {
            var userAgent = navigator.userAgent.toLowerCase();
            return userAgent.indexOf("micromessenger") > -1 || userAgent.indexOf("qqbrowser") > -1;
        };
        ImportExportCSV.prototype.exportCSVFile = function (options) {
            if (this.isWechatOrQQBrowser()) {
                alert("请在浏览器中打开该网页后再下载。");
                this.resumeCommand();
                return;
            }
            var data = [];
            var rowCount = options.listview.getRowCount();
            for (var r = 0; r < rowCount; r++) {
                var rowData = [];
                for (var i = 0; i < options.columnIndexListInListView.length; i++) {
                    var c = options.columnIndexListInListView[i];
                    var val = c === -1 ? null : options.listview.getText(r, c);
                    rowData.push(val);
                }
                data.push(rowData);
            }
            var csv = window.Papa.unparse({
                fields: options.importExportHeaderRow ? options.columnNames : undefined,
                data: data.length === 0 ? null : data
            }, {
                delimiter: options.columnDelimiter,
                newline: options.lineDelimiter,
                quotes: options.forceTextQualifier,
                quoteChar: options.textQualifier
            });
            //download csv file
            var fileExtension = this.getActualFileExtension(options.fileExtension);
            var fileName = options.csvFileName + fileExtension;
            var BOM = "\uFEFF";
            var blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
            if (window.navigator.msSaveOrOpenBlob) { // IE hack; see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
                window.navigator.msSaveBlob(blob, fileName);
            }
            else {
                var a = window.document.createElement("a");
                a.href = window.URL.createObjectURL(blob);
                a.download = fileName;
                document.body.appendChild(a);
                a.click(); // IE: "Access is denied"; see: https://connect.microsoft.com/IE/feedback/details/797361/ie-10-treats-blob-url-as-cross-origin-and-denies-access
                document.body.removeChild(a);
            }
            this.resumeCommand();
        };
        ImportExportCSV.prototype.platformIsChrome = function () {
            return !this.platformIsOldEdge() && navigator.userAgent.indexOf("Chrome/") !== -1;
        };
        ImportExportCSV.prototype.platformIsOldEdge = function () {
            return navigator.userAgent.indexOf("Edge/") !== -1;
        };
        return ImportExportCSV;
    }(Forguncy.Plugin.CommandBase));
    ImportExportCSVCommand.ImportExportCSV = ImportExportCSV;
    var CSVOperation;
    (function (CSVOperation) {
        CSVOperation[CSVOperation["Import"] = 0] = "Import";
        CSVOperation[CSVOperation["Export"] = 1] = "Export";
    })(CSVOperation || (CSVOperation = {}));
})(ImportExportCSVCommand || (ImportExportCSVCommand = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CommandFactory.registerCommand("ImportExportCSV.ImportExportCSV, ImportExportCSV", ImportExportCSVCommand.ImportExportCSV);
